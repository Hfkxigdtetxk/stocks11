import pandas as pd
import yfinance as yf
from datetime import datetime, timedelta
import time
import os
import logging
import requests
from bs4 import BeautifulSoup

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class YahooFinanceScraper:
    """
    Scraper for retrieving detailed data from Yahoo Finance
    Provides more comprehensive data than the Google Finance scraper
    """
    
    def __init__(self):
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
            "Cache-Control": "max-age=0"
        }
    
    def _format_ticker(self, symbol):
        """
        Format ticker symbol for yfinance API
        
        Args:
            symbol (str): Stock symbol/ticker
            
        Returns:
            str: Formatted ticker symbol
        """
        # No need to add .NS for AAPL like symbols
        # Just return the symbol as is unless it explicitly has NSE or BSE identifiers
        
        # NSE symbols usually have .NS suffix
        if symbol.endswith('.NS') or symbol.endswith('.BO'):
            return symbol
            
        # If it's an Indian exchange symbol without suffix but specified as such
        if symbol in ['RELIANCE', 'INFY', 'TCS', 'HDFCBANK'] and '.NS' not in symbol and '.BO' not in symbol:
            # Only add .NS if it's explicitly from NSE
            # This is a heuristic - we're assuming these major Indian stocks
            return f"{symbol}.NS"
        
        # For all other cases, return as is (US stocks, etc.)
        return symbol
    
    def get_price_data(self, symbol, start_date, end_date):
        """
        Retrieves comprehensive historical price data for a given stock symbol
        
        Args:
            symbol (str): Stock symbol/ticker
            start_date (datetime.date): Start date for data retrieval
            end_date (datetime.date): End date for data retrieval
            
        Returns:
            pandas.DataFrame: DataFrame containing price data
        """
        try:
            logger.info(f"Fetching Yahoo Finance price data for {symbol} from {start_date} to {end_date}")
            
            # Format ticker symbol
            ticker = self._format_ticker(symbol)
            
            # Download data using yfinance
            # Note: yfinance requires end_date + 1 day to include the end_date in results
            df = yf.download(ticker, start=start_date, end=end_date + timedelta(days=1), auto_adjust=True)
            
            if not df.empty:
                # Ensure all standard columns are present
                expected_columns = ['Open', 'High', 'Low', 'Close', 'Volume']
                
                # Check if all expected columns exist
                missing_columns = [col for col in expected_columns if col not in df.columns]
                if missing_columns:
                    logger.warning(f"Missing columns in data: {missing_columns}")
                    # Add missing columns with NaN values
                    for col in missing_columns:
                        df[col] = pd.NA
                
                # Convert index to datetime if it's not already
                if not isinstance(df.index, pd.DatetimeIndex):
                    df.index = pd.to_datetime(df.index)
                
                # Get additional data like market cap and other metrics
                try:
                    # Get ticker info for additional data
                    ticker_obj = yf.Ticker(ticker)
                    ticker_info = ticker_obj.info
                    
                    # Add market cap as a constant value
                    if 'marketCap' in ticker_info:
                        df['MarketCap'] = ticker_info['marketCap']
                        
                    # Add sector and industry information
                    if 'sector' in ticker_info:
                        df['Sector'] = ticker_info['sector']
                        
                    if 'industry' in ticker_info:
                        df['Industry'] = ticker_info['industry']
                        
                    # Add beta value
                    if 'beta' in ticker_info:
                        df['Beta'] = ticker_info['beta']
                        
                    # Get dividends and stock splits
                    actions = ticker_obj.actions
                    if not actions.empty:
                        df = df.join(actions, how='left')
                    
                    # Get analyst recommendations
                    recommendations = ticker_obj.recommendations
                    if not recommendations.empty:
                        # Use the most recent recommendation for each date
                        latest_rec = recommendations.groupby(recommendations.index.date).last()
                        # Join with price data
                        df = df.join(latest_rec, how='left')
                    
                except Exception as e:
                    logger.warning(f"Could not get additional ticker info: {str(e)}")
                
                return df
            else:
                logger.warning(f"No data available for {symbol} in the specified date range")
                return pd.DataFrame()
                
        except Exception as e:
            logger.error(f"Error fetching price data for {symbol}: {str(e)}")
            return pd.DataFrame()
    
    def get_options_data(self, symbol, expiry_date=None):
        """
        Retrieves options data for a given stock symbol
        
        Args:
            symbol (str): Stock symbol/ticker
            expiry_date (datetime.date, optional): Specific expiry date for options
            
        Returns:
            tuple: (calls_df, puts_df) as pandas DataFrames
        """
        try:
            # Format ticker symbol
            ticker = self._format_ticker(symbol)
            ticker_obj = yf.Ticker(ticker)
            
            # Get options expiry dates
            expirations = ticker_obj.options
            
            if not expirations:
                logger.warning(f"No options data available for {symbol}")
                return pd.DataFrame(), pd.DataFrame()
            
            # If no expiry date is specified, use the nearest one
            if expiry_date is None:
                expiry = expirations[0]
            else:
                # Convert expiry_date to string format YYYY-MM-DD
                expiry_str = expiry_date.strftime('%Y-%m-%d')
                # Find closest expiry date
                if expiry_str in expirations:
                    expiry = expiry_str
                else:
                    # Use the nearest available expiry date
                    expiry = expirations[0]
                    logger.warning(f"Requested expiry date {expiry_str} not available, using {expiry} instead")
            
            # Get option chain for this expiry
            logger.info(f"Fetching options data for {symbol} with expiry {expiry}")
            opt = ticker_obj.option_chain(expiry)
            
            return opt.calls, opt.puts
            
        except Exception as e:
            logger.error(f"Error fetching options data for {symbol}: {str(e)}")
            return pd.DataFrame(), pd.DataFrame()
    
    def get_institutional_holders(self, symbol):
        """
        Retrieves institutional holders data for a given stock symbol
        
        Args:
            symbol (str): Stock symbol/ticker
            
        Returns:
            pandas.DataFrame: DataFrame containing institutional holders data
        """
        try:
            # Format ticker symbol
            ticker = self._format_ticker(symbol)
            ticker_obj = yf.Ticker(ticker)
            
            # Get institutional holders
            logger.info(f"Fetching institutional holders data for {symbol}")
            holders = ticker_obj.institutional_holders
            
            return holders
            
        except Exception as e:
            logger.error(f"Error fetching institutional holders data for {symbol}: {str(e)}")
            return pd.DataFrame()
    
    def get_financials(self, symbol, statement_type='income'):
        """
        Retrieves financial statements for a given stock symbol
        
        Args:
            symbol (str): Stock symbol/ticker
            statement_type (str): Type of financial statement ('income', 'balance', 'cash')
            
        Returns:
            pandas.DataFrame: DataFrame containing financial statement data
        """
        try:
            # Format ticker symbol
            ticker = self._format_ticker(symbol)
            ticker_obj = yf.Ticker(ticker)
            
            logger.info(f"Fetching {statement_type} statement data for {symbol}")
            
            if statement_type == 'income':
                financials = ticker_obj.income_stmt
            elif statement_type == 'balance':
                financials = ticker_obj.balance_sheet
            elif statement_type == 'cash':
                financials = ticker_obj.cashflow
            else:
                logger.warning(f"Unknown statement type: {statement_type}")
                return pd.DataFrame()
            
            return financials
            
        except Exception as e:
            logger.error(f"Error fetching {statement_type} statement data for {symbol}: {str(e)}")
            return pd.DataFrame()
    
    def get_fii_dii_data(self, start_date, end_date):
        """Placeholder method - relies on NSE data which is accessed through API"""
        logger.warning("Yahoo Finance doesn't provide FII/DII data. Use NSE or BSE scraper instead.")
        return pd.DataFrame()
    
    def get_block_deals(self, symbol, start_date, end_date):
        """Placeholder method - relies on exchange-specific data"""
        logger.warning("Yahoo Finance doesn't provide block deals data. Use NSE or BSE scraper instead.")
        return pd.DataFrame()
    
    def get_bulk_deals(self, symbol, start_date, end_date):
        """Placeholder method - relies on exchange-specific data"""
        logger.warning("Yahoo Finance doesn't provide bulk deals data. Use NSE or BSE scraper instead.")
        return pd.DataFrame()
    
    def get_short_selling_data(self, symbol, start_date, end_date):
        """
        Retrieves short selling data for a given stock symbol
        
        Args:
            symbol (str): Stock symbol/ticker
            start_date (datetime.date): Start date for data retrieval
            end_date (datetime.date): End date for data retrieval
            
        Returns:
            pandas.DataFrame: DataFrame containing short selling data
        """
        try:
            logger.info(f"Fetching short selling data for {symbol} from {start_date} to {end_date}")
            
            # Format ticker
            ticker = self._format_ticker(symbol)
            
            # Get price data first (needed for volume comparison)
            price_data = self.get_price_data(symbol, start_date, end_date)
            
            if price_data.empty:
                logger.warning(f"No price data available for {symbol}, cannot calculate short selling metrics")
                return pd.DataFrame()
            
            # Try to get short interest data using Yahoo Finance ticker object
            ticker_obj = yf.Ticker(ticker)
            
            # Create a dataframe for short data
            short_data = []
            
            try:
                # Get short interest data from key statistics
                ticker_info = ticker_obj.info
                
                # Check for short interest metrics
                short_metrics = {
                    'shortPercentOfFloat': 'Short % of Float',
                    'sharesShort': 'Shares Short',
                    'sharesShortPriorMonth': 'Shares Short (Prior Month)',
                    'shortRatio': 'Short Ratio',
                    'sharesShortPreviousMonthDate': 'Short Data Date'
                }
                
                has_short_data = False
                
                # Extract available short interest metrics
                for key, label in short_metrics.items():
                    if key in ticker_info and ticker_info[key] is not None:
                        has_short_data = True
                
                if has_short_data:
                    # Use the most recent date from price data
                    recent_date = price_data.index[-1].date()
                    
                    # Create short data entry
                    short_entry = {
                        'Date': recent_date,
                        'Symbol': symbol
                    }
                    
                    # Add available metrics
                    for key, label in short_metrics.items():
                        if key in ticker_info and ticker_info[key] is not None:
                            short_entry[label] = ticker_info[key]
                    
                    # Calculate additional metrics if possible
                    if 'Shares Short' in short_entry and 'Volume' in price_data.columns:
                        # Get average volume for comparison
                        avg_volume = price_data['Volume'].mean()
                        if avg_volume > 0:
                            short_entry['Days to Cover'] = short_entry.get('Shares Short', 0) / avg_volume
                    
                    short_data.append(short_entry)
            
            except Exception as e:
                logger.warning(f"Could not extract short interest data: {str(e)}")
            
            if short_data:
                df = pd.DataFrame(short_data)
                df.set_index('Date', inplace=True)
                return df
            else:
                logger.warning(f"No short selling data found for {symbol}")
                return pd.DataFrame()
            
        except Exception as e:
            logger.error(f"Error fetching short selling data for {symbol}: {str(e)}")
            return pd.DataFrame()
