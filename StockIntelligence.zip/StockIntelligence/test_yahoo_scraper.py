import pandas as pd
import datetime
from scrapers.yahoo_finance_scraper import YahooFinanceScraper
from utils.excel_manager import ExcelManager

def test_yahoo_finance_scraping():
    # Create an instance of the Yahoo Finance scraper
    scraper = YahooFinanceScraper()
    
    # Define parameters
    symbol = "AAPL"  # Apple Inc.
    end_date = datetime.date.today()
    start_date = end_date - datetime.timedelta(days=30)  # Last 30 days
    
    print(f"Testing Yahoo Finance scraper for {symbol} from {start_date} to {end_date}")
    
    # Fetch price data
    print("Fetching price data...")
    price_data = scraper.get_price_data(symbol, start_date, end_date)
    if not price_data.empty:
        print(f"Successfully retrieved {len(price_data)} rows of price data")
        print(price_data.head())
    else:
        print("Failed to retrieve price data")
    
    # Export to Excel
    if not price_data.empty:
        excel_manager = ExcelManager(output_dir="data")
        filename = f"{symbol}_test_data.xlsx"
        path = excel_manager.export_to_excel(price_data, filename, sheet_name="Price Data")
        if path:
            print(f"Exported data to {path}")
        else:
            print("Failed to export data to Excel")

if __name__ == "__main__":
    test_yahoo_finance_scraping()
