import pandas as pd
import requests
import logging
import json
import os
from datetime import datetime, timedelta

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class AlphaVantageScraper:
    """
    Scraper for retrieving data from Alpha Vantage API
    Provides access to stock quotes, technical indicators, and fundamental data
    """
    
    def __init__(self, api_key=None):
        """
        Initialize the Alpha Vantage scraper
        
        Args:
            api_key (str, optional): Alpha Vantage API key
        """
        # Try to get API key from environment variable if not provided
        self.api_key = api_key or os.environ.get("ALPHA_VANTAGE_API_KEY")
        self.base_url = "https://www.alphavantage.co/query"
        
        if not self.api_key:
            logger.warning("No Alpha Vantage API key provided. Some functions may not work correctly.")
    
    def _format_ticker(self, symbol):
        """
        Format ticker symbol for Alpha Vantage API
        
        Args:
            symbol (str): Stock symbol/ticker
            
        Returns:
            str: Formatted ticker symbol
        """
        # Remove any exchange suffix like .NS
        if "." in symbol:
            parts = symbol.split(".")
            symbol = parts[0]
        return symbol.upper()
    
    def get_price_data(self, symbol, start_date, end_date):
        """
        Retrieves historical price data for a given stock symbol
        
        Args:
            symbol (str): Stock symbol/ticker
            start_date (datetime.date): Start date for data retrieval
            end_date (datetime.date): End date for data retrieval
            
        Returns:
            pandas.DataFrame: DataFrame containing price data
        """
        logger.info(f"Fetching Alpha Vantage price data for {symbol} from {start_date} to {end_date}")
        
        try:
            # Format ticker for API
            ticker = self._format_ticker(symbol)
            
            # Create request parameters
            params = {
                "function": "TIME_SERIES_DAILY",
                "symbol": ticker,
                "outputsize": "full" if (end_date - start_date).days > 100 else "compact",
                "datatype": "json",
                "apikey": self.api_key
            }
            
            # Send request to Alpha Vantage API
            response = requests.get(self.base_url, params=params)
            
            if response.status_code != 200:
                logger.error(f"Failed to retrieve data: Status code {response.status_code}")
                return pd.DataFrame()
            
            # Parse response data
            data = response.json()
            
            if "Time Series (Daily)" not in data:
                if "Error Message" in data:
                    logger.error(f"API error: {data['Error Message']}")
                elif "Note" in data:
                    logger.warning(f"API limit reached: {data['Note']}")
                else:
                    logger.error("Unexpected API response format")
                return pd.DataFrame()
            
            # Extract time series data
            time_series = data["Time Series (Daily)"]
            
            # Create DataFrame from time series
            df = pd.DataFrame.from_dict(time_series, orient="index")
            
            # Rename columns
            df.rename(columns={
                "1. open": "Open",
                "2. high": "High",
                "3. low": "Low",
                "4. close": "Close",
                "5. volume": "Volume"
            }, inplace=True)
            
            # Convert index to datetime
            df.index = pd.to_datetime(df.index)
            
            # Filter by date range
            df = df[(df.index.date >= start_date) & (df.index.date <= end_date)]
            
            # Convert columns to numeric
            for col in df.columns:
                df[col] = pd.to_numeric(df[col])
            
            # Sort by date
            df = df.sort_index()
            
            return df
            
        except Exception as e:
            logger.error(f"Error retrieving price data: {str(e)}")
            return pd.DataFrame()
    
    def get_technical_indicators(self, symbol, indicator, params=None):
        """
        Retrieves technical indicator data for a given stock symbol
        
        Args:
            symbol (str): Stock symbol/ticker
            indicator (str): Technical indicator to retrieve (e.g., SMA, EMA, RSI)
            params (dict, optional): Additional parameters for the indicator
            
        Returns:
            pandas.DataFrame: DataFrame containing technical indicator data
        """
        logger.info(f"Fetching Alpha Vantage {indicator} data for {symbol}")
        
        try:
            # Format ticker for API
            ticker = self._format_ticker(symbol)
            
            # Default parameters
            indicator_params = {
                "function": indicator,
                "symbol": ticker,
                "interval": "daily",
                "time_period": 14,  # Default time period
                "series_type": "close",
                "apikey": self.api_key
            }
            
            # Update with custom parameters if provided
            if params:
                indicator_params.update(params)
            
            # Send request to Alpha Vantage API
            response = requests.get(self.base_url, params=indicator_params)
            
            if response.status_code != 200:
                logger.error(f"Failed to retrieve data: Status code {response.status_code}")
                return pd.DataFrame()
            
            # Parse response data
            data = response.json()
            
            # Check for API errors
            if "Error Message" in data:
                logger.error(f"API error: {data['Error Message']}")
                return pd.DataFrame()
            
            if "Note" in data:
                logger.warning(f"API limit reached: {data['Note']}")
                return pd.DataFrame()
            
            # Get the indicator data key (varies by indicator)
            indicator_key = None
            for key in data.keys():
                if key.startswith("Technical Analysis"):
                    indicator_key = key
                    break
            
            if not indicator_key:
                logger.error("Could not find technical indicator data in response")
                return pd.DataFrame()
            
            # Extract technical indicator data
            indicator_data = data[indicator_key]
            
            # Create DataFrame from indicator data
            df = pd.DataFrame.from_dict(indicator_data, orient="index")
            
            # Convert index to datetime
            df.index = pd.to_datetime(df.index)
            
            # Convert columns to numeric
            for col in df.columns:
                df[col] = pd.to_numeric(df[col])
            
            # Sort by date
            df = df.sort_index()
            
            return df
            
        except Exception as e:
            logger.error(f"Error retrieving technical indicator data: {str(e)}")
            return pd.DataFrame()
    
    def get_fundamental_data(self, symbol, data_type="overview"):
        """
        Retrieves fundamental data for a given stock symbol
        
        Args:
            symbol (str): Stock symbol/ticker
            data_type (str): Type of fundamental data to retrieve
                             (overview, income, balance, cash)
            
        Returns:
            pandas.DataFrame: DataFrame containing fundamental data
        """
        logger.info(f"Fetching Alpha Vantage fundamental {data_type} data for {symbol}")
        
        try:
            # Format ticker for API
            ticker = self._format_ticker(symbol)
            
            # Map data_type to Alpha Vantage function
            function_map = {
                "overview": "OVERVIEW",
                "income": "INCOME_STATEMENT",
                "balance": "BALANCE_SHEET",
                "cash": "CASH_FLOW",
                "earnings": "EARNINGS"
            }
            
            if data_type not in function_map:
                logger.error(f"Invalid data type: {data_type}")
                return pd.DataFrame()
            
            # Create request parameters
            params = {
                "function": function_map[data_type],
                "symbol": ticker,
                "apikey": self.api_key
            }
            
            # Send request to Alpha Vantage API
            response = requests.get(self.base_url, params=params)
            
            if response.status_code != 200:
                logger.error(f"Failed to retrieve data: Status code {response.status_code}")
                return pd.DataFrame()
            
            # Parse response data
            data = response.json()
            
            # Check for API errors
            if "Error Message" in data:
                logger.error(f"API error: {data['Error Message']}")
                return pd.DataFrame()
            
            if "Note" in data:
                logger.warning(f"API limit reached: {data['Note']}")
                return pd.DataFrame()
            
            # For company overview, convert to DataFrame
            if data_type == "overview":
                df = pd.DataFrame([data])
                return df
            
            # For financial statements, structure varies
            if data_type in ["income", "balance", "cash"]:
                if "annualReports" in data:
                    reports = data["annualReports"]
                    df = pd.DataFrame(reports)
                    
                    # Convert date columns
                    if "fiscalDateEnding" in df.columns:
                        df["fiscalDateEnding"] = pd.to_datetime(df["fiscalDateEnding"])
                        df = df.set_index("fiscalDateEnding")
                    
                    # Convert numeric columns
                    for col in df.columns:
                        try:
                            df[col] = pd.to_numeric(df[col])
                        except:
                            # Keep as string if can't convert to numeric
                            pass
                    
                    return df
            
            # For earnings data
            if data_type == "earnings":
                if "annualEarnings" in data:
                    earnings = data["annualEarnings"]
                    df = pd.DataFrame(earnings)
                    
                    # Convert date columns
                    if "fiscalDateEnding" in df.columns:
                        df["fiscalDateEnding"] = pd.to_datetime(df["fiscalDateEnding"])
                        df = df.set_index("fiscalDateEnding")
                    
                    # Convert numeric columns
                    if "reportedEPS" in df.columns:
                        df["reportedEPS"] = pd.to_numeric(df["reportedEPS"])
                    
                    return df
            
            # If we couldn't process the data properly
            logger.warning(f"Could not properly process {data_type} data")
            return pd.DataFrame()
            
        except Exception as e:
            logger.error(f"Error retrieving fundamental data: {str(e)}")
            return pd.DataFrame()
    
    def get_fii_dii_data(self, start_date, end_date):
        """Alpha Vantage doesn't provide FII/DII data"""
        logger.warning("Alpha Vantage doesn't provide FII/DII data. Use NSE or BSE scraper instead.")
        return pd.DataFrame()
    
    def get_block_deals(self, symbol, start_date, end_date):
        """Alpha Vantage doesn't provide block deals data"""
        logger.warning("Alpha Vantage doesn't provide block deals data. Use NSE or BSE scraper instead.")
        return pd.DataFrame()
    
    def get_bulk_deals(self, symbol, start_date, end_date):
        """Alpha Vantage doesn't provide bulk deals data"""
        logger.warning("Alpha Vantage doesn't provide bulk deals data. Use NSE or BSE scraper instead.")
        return pd.DataFrame()
    
    def get_short_selling_data(self, symbol, start_date, end_date):
        """Alpha Vantage doesn't provide short selling data"""
        logger.warning("Alpha Vantage doesn't provide short selling data.")
        return pd.DataFrame()
