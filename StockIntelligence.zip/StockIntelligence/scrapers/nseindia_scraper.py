import pandas as pd
import requests
from datetime import datetime, timedelta
import time
import os
import json
from io import StringIO
import logging
from bs4 import BeautifulSoup

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class NSEIndiaScraper:
    """
    Scraper for retrieving data from the National Stock Exchange of India (NSE)
    """
    
    def __init__(self):
        self.base_url = "https://www.nseindia.com"
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
            "Cache-Control": "max-age=0"
        }
    
    def get_price_data(self, symbol, start_date, end_date):
        """
        Retrieves historical price data for a given stock symbol
        
        Args:
            symbol (str): Stock symbol/ticker
            start_date (datetime.date): Start date for data retrieval
            end_date (datetime.date): End date for data retrieval
            
        Returns:
            pandas.DataFrame: DataFrame containing price data
        """
        try:
            logger.info(f"Fetching NSE price data for {symbol} from {start_date} to {end_date}")
            
            # Convert dates to strings in required format
            from_date = start_date.strftime('%d-%m-%Y')
            to_date = end_date.strftime('%d-%m-%Y')
            
            # Build URL for historical data
            url = f"{self.base_url}/api/historical/cm/equity?symbol={symbol}&from={from_date}&to={to_date}"
            
            # Add delay to avoid rate limiting
            time.sleep(1)
            
            response = requests.get(url, headers=self.headers)
            
            if response.status_code == 200:
                data = response.json()
                
                if 'data' in data and data['data']:
                    # Convert to DataFrame
                    df = pd.DataFrame(data['data'])
                    
                    # Rename columns to standard format
                    df.rename(columns={
                        'CH_TIMESTAMP': 'Date',
                        'CH_OPENING_PRICE': 'Open',
                        'CH_TRADE_HIGH_PRICE': 'High',
                        'CH_TRADE_LOW_PRICE': 'Low',
                        'CH_CLOSING_PRICE': 'Close',
                        'CH_TOT_TRADED_VAL': 'Value',
                        'CH_TOT_TRADED_QTY': 'Volume'
                    }, inplace=True)
                    
                    # Convert date column to datetime
                    df['Date'] = pd.to_datetime(df['Date'])
                    df.set_index('Date', inplace=True)
                    
                    # Convert numeric columns
                    numeric_columns = ['Open', 'High', 'Low', 'Close', 'Volume', 'Value']
                    for col in numeric_columns:
                        if col in df.columns:
                            df[col] = pd.to_numeric(df[col], errors='coerce')
                    
                    # Sort by date in ascending order
                    df.sort_index(inplace=True)
                    
                    return df
                else:
                    logger.warning(f"No data available for {symbol} in the specified date range")
                    return pd.DataFrame()
            else:
                logger.error(f"Failed to retrieve data: Status code {response.status_code}")
                return pd.DataFrame()
                
        except Exception as e:
            logger.error(f"Error fetching price data for {symbol}: {str(e)}")
            # Try alternative approach using yfinance for NSE stocks
            try:
                import yfinance as yf
                ticker = f"{symbol}.NS"
                df = yf.download(ticker, start=start_date, end=end_date + timedelta(days=1))
                if not df.empty:
                    return df
                else:
                    return pd.DataFrame()
            except Exception as e2:
                logger.error(f"Error with alternative approach: {str(e2)}")
                return pd.DataFrame()
    
    def get_fii_dii_data(self, start_date, end_date):
        """
        Retrieves FII/DII data for the specified time period
        
        Args:
            start_date (datetime.date): Start date for data retrieval
            end_date (datetime.date): End date for data retrieval
            
        Returns:
            pandas.DataFrame: DataFrame containing FII/DII data
        """
        try:
            logger.info(f"Fetching NSE FII/DII data from {start_date} to {end_date}")
            
            # This endpoint requires a different approach
            url = f"{self.base_url}/api/fiidiiTradeReact"
            
            all_data = []
            current_date = start_date
            
            while current_date <= end_date:
                date_str = current_date.strftime('%d-%b-%Y')
                
                # Add delay to avoid rate limiting
                time.sleep(1)
                
                params = {
                    "date": date_str
                }
                
                response = requests.get(url, headers=self.headers, params=params)
                
                if response.status_code == 200:
                    data = response.json()
                    
                    if data and isinstance(data, dict) and 'data' in data:
                        for item in data['data']:
                            item['Date'] = current_date
                            all_data.append(item)
                
                # Move to next day
                current_date += timedelta(days=1)
            
            if all_data:
                df = pd.DataFrame(all_data)
                
                # Process and cleanup the DataFrame
                if 'category' in df.columns:
                    # Pivot the data to have FII and DII as separate columns
                    pivot_df = df.pivot(index='Date', columns='category', values=['buyValue', 'sellValue'])
                    
                    # Flatten multi-level columns
                    pivot_df.columns = [f"{col[1]} {col[0]}" for col in pivot_df.columns]
                    
                    # Rename columns to more readable format
                    pivot_df.rename(columns={
                        'FII buyValue': 'FII Buy',
                        'FII sellValue': 'FII Sell',
                        'DII buyValue': 'DII Buy',
                        'DII sellValue': 'DII Sell'
                    }, inplace=True)
                    
                    # Calculate net positions
                    if all(col in pivot_df.columns for col in ['FII Buy', 'FII Sell']):
                        pivot_df['FII Net'] = pivot_df['FII Buy'] - pivot_df['FII Sell']
                    
                    if all(col in pivot_df.columns for col in ['DII Buy', 'DII Sell']):
                        pivot_df['DII Net'] = pivot_df['DII Buy'] - pivot_df['DII Sell']
                    
                    return pivot_df
                
                # If pivoting didn't work, return the original dataframe
                df.set_index('Date', inplace=True)
                return df
            else:
                logger.warning("No FII/DII data found for the specified date range")
                return pd.DataFrame()
            
        except Exception as e:
            logger.error(f"Error fetching FII/DII data: {str(e)}")
            return pd.DataFrame()
    
    def get_block_deals(self, symbol, start_date, end_date):
        """
        Retrieves block deals data for a given stock symbol
        
        Args:
            symbol (str): Stock symbol/ticker
            start_date (datetime.date): Start date for data retrieval
            end_date (datetime.date): End date for data retrieval
            
        Returns:
            pandas.DataFrame: DataFrame containing block deals data
        """
        try:
            logger.info(f"Fetching NSE block deals for {symbol} from {start_date} to {end_date}")
            
            # NSE block deals API endpoint
            url = f"{self.base_url}/api/block-deal"
            
            all_deals = []
            current_date = start_date
            
            while current_date <= end_date:
                date_str = current_date.strftime('%d-%m-%Y')
                
                # Add delay to avoid rate limiting
                time.sleep(1)
                
                params = {
                    "index": "CM",
                    "date": date_str
                }
                
                response = requests.get(url, headers=self.headers, params=params)
                
                if response.status_code == 200:
                    data = response.json()
                    
                    if data and 'data' in data and data['data']:
                        for deal in data['data']:
                            # Filter for the requested symbol
                            if deal.get('symbol') == symbol:
                                deal['Date'] = current_date
                                all_deals.append(deal)
                
                # Move to next day
                current_date += timedelta(days=1)
            
            if all_deals:
                df = pd.DataFrame(all_deals)
                
                # Rename columns to standard format
                df.rename(columns={
                    'clientName': 'Client Name',
                    'symbol': 'Symbol',
                    'quantity': 'Quantity',
                    'tradePrice': 'Price',
                    'value': 'Value'
                }, inplace=True)
                
                # Convert date to datetime and set as index
                df['Date'] = pd.to_datetime(df['Date'])
                df.set_index('Date', inplace=True)
                
                # Convert numeric columns
                numeric_columns = ['Quantity', 'Price', 'Value']
                for col in numeric_columns:
                    if col in df.columns:
                        df[col] = pd.to_numeric(df[col], errors='coerce')
                
                return df
            else:
                logger.warning(f"No block deals found for {symbol} in the specified date range")
                return pd.DataFrame()
            
        except Exception as e:
            logger.error(f"Error fetching block deals data for {symbol}: {str(e)}")
            return pd.DataFrame()
    
    def get_bulk_deals(self, symbol, start_date, end_date):
        """
        Retrieves bulk deals data for a given stock symbol
        
        Args:
            symbol (str): Stock symbol/ticker
            start_date (datetime.date): Start date for data retrieval
            end_date (datetime.date): End date for data retrieval
            
        Returns:
            pandas.DataFrame: DataFrame containing bulk deals data
        """
        try:
            logger.info(f"Fetching NSE bulk deals for {symbol} from {start_date} to {end_date}")
            
            # NSE bulk deals API endpoint
            url = f"{self.base_url}/api/bulk-deal"
            
            all_deals = []
            current_date = start_date
            
            while current_date <= end_date:
                date_str = current_date.strftime('%d-%m-%Y')
                
                # Add delay to avoid rate limiting
                time.sleep(1)
                
                params = {
                    "index": "CM",
                    "date": date_str
                }
                
                response = requests.get(url, headers=self.headers, params=params)
                
                if response.status_code == 200:
                    data = response.json()
                    
                    if data and 'data' in data and data['data']:
                        for deal in data['data']:
                            # Filter for the requested symbol
                            if deal.get('symbol') == symbol:
                                deal['Date'] = current_date
                                all_deals.append(deal)
                
                # Move to next day
                current_date += timedelta(days=1)
            
            if all_deals:
                df = pd.DataFrame(all_deals)
                
                # Rename columns to standard format
                df.rename(columns={
                    'clientName': 'Client Name',
                    'symbol': 'Symbol',
                    'quantity': 'Quantity',
                    'price': 'Price',
                    'value': 'Value',
                    'buySell': 'Transaction Type'
                }, inplace=True)
                
                # Convert date to datetime and set as index
                df['Date'] = pd.to_datetime(df['Date'])
                df.set_index('Date', inplace=True)
                
                # Convert numeric columns
                numeric_columns = ['Quantity', 'Price', 'Value']
                for col in numeric_columns:
                    if col in df.columns:
                        df[col] = pd.to_numeric(df[col], errors='coerce')
                
                return df
            else:
                logger.warning(f"No bulk deals found for {symbol} in the specified date range")
                return pd.DataFrame()
            
        except Exception as e:
            logger.error(f"Error fetching bulk deals data for {symbol}: {str(e)}")
            return pd.DataFrame()
    
    def get_short_selling_data(self, symbol, start_date, end_date):
        """
        Retrieves short selling data for a given stock symbol
        
        Args:
            symbol (str): Stock symbol/ticker
            start_date (datetime.date): Start date for data retrieval
            end_date (datetime.date): End date for data retrieval
            
        Returns:
            pandas.DataFrame: DataFrame containing short selling data
        """
        try:
            logger.info(f"Fetching NSE short selling data for {symbol} from {start_date} to {end_date}")
            
            # NSE doesn't provide direct API for short selling data
            # Attempting to get data from SEBI's website as an alternative
            url = "https://www.sebi.gov.in/sebiweb/other/OtherAction.do?doRecognisedFpi=yes&intmId=42"
            
            response = requests.get(url, headers=self.headers)
            
            if response.status_code == 200:
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # This is a simplified approach as SEBI's website structure may change
                # Look for tables containing short selling data
                tables = soup.find_all('table')
                
                short_data = []
                
                for table in tables:
                    rows = table.find_all('tr')
                    for row in rows:
                        cells = row.find_all('td')
                        if len(cells) >= 4:
                            # Check if this row contains our symbol
                            if symbol in cells[0].text:
                                try:
                                    date_text = cells[1].text.strip()
                                    date = datetime.strptime(date_text, '%d-%m-%Y').date()
                                    
                                    if start_date <= date <= end_date:
                                        short_data.append({
                                            'Date': date,
                                            'Symbol': symbol,
                                            'Short Volume': float(cells[2].text.strip().replace(',', '')),
                                            'Short Value': float(cells[3].text.strip().replace(',', ''))
                                        })
                                except (ValueError, IndexError):
                                    continue
                
                if short_data:
                    df = pd.DataFrame(short_data)
                    df.set_index('Date', inplace=True)
                    
                    # Calculate short ratio if volume data is available
                    if 'Short Volume' in df.columns:
                        # Get the daily volume from price data
                        price_data = self.get_price_data(symbol, start_date, end_date)
                        if not price_data.empty and 'Volume' in price_data.columns:
                            # Merge datasets
                            df = df.join(price_data[['Volume']], how='left')
                            # Calculate short ratio
                            df['Short Ratio'] = df['Short Volume'] / df['Volume']
                    
                    return df
                else:
                    logger.warning(f"No short selling data found for {symbol}")
                    # Create a synthetic dataset for illustration
                    return pd.DataFrame()
            else:
                logger.error(f"Failed to retrieve short selling data: Status code {response.status_code}")
                return pd.DataFrame()
            
        except Exception as e:
            logger.error(f"Error fetching short selling data for {symbol}: {str(e)}")
            return pd.DataFrame()
