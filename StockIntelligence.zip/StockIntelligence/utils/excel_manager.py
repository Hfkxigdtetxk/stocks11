import pandas as pd
import os
import logging
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class ExcelManager:
    """
    Utility class for managing Excel exports of stock market data
    Provides functionality to create, update, and manage Excel workbooks
    """
    
    def __init__(self, output_dir='exports'):
        """
        Initialize the Excel Manager
        
        Args:
            output_dir (str): Directory to save Excel files, default is 'exports'
        """
        self.output_dir = output_dir
        
        # Create the exports directory if it doesn't exist
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
            logger.info(f"Created exports directory: {output_dir}")
    
    def export_to_excel(self, data, filename, sheet_name=None, append=False):
        """
        Export data to an Excel file
        
        Args:
            data (pandas.DataFrame): DataFrame to export
            filename (str): Name of the Excel file (without path)
            sheet_name (str, optional): Name of the sheet, default is 'Sheet1'
            append (bool): Whether to append to an existing file, default is False
            
        Returns:
            str: Path to the saved Excel file
        """
        try:
            if data.empty:
                logger.warning("Cannot export empty data to Excel")
                return None
            
            # Set default sheet name if not provided
            if not sheet_name:
                sheet_name = 'Sheet1'
            
            # Ensure filename has .xlsx extension
            if not filename.endswith('.xlsx'):
                filename = f"{filename}.xlsx"
            
            # Full path to the Excel file
            file_path = os.path.join(self.output_dir, filename)
            
            # Check if file exists and append mode is enabled
            if append and os.path.exists(file_path):
                # Load existing workbook
                try:
                    with pd.ExcelWriter(file_path, mode='a', engine='openpyxl', if_sheet_exists='replace') as writer:
                        data.to_excel(writer, sheet_name=sheet_name)
                        logger.info(f"Appended data to sheet '{sheet_name}' in {file_path}")
                except Exception as e:
                    # If append failed, try creating a new file
                    logger.warning(f"Could not append to existing file: {str(e)}. Creating new file instead.")
                    with pd.ExcelWriter(file_path, mode='w', engine='openpyxl') as writer:
                        data.to_excel(writer, sheet_name=sheet_name)
                        logger.info(f"Created new Excel file: {file_path}")
            else:
                # Create new file
                with pd.ExcelWriter(file_path, mode='w', engine='openpyxl') as writer:
                    data.to_excel(writer, sheet_name=sheet_name)
                    logger.info(f"Created new Excel file: {file_path}")
            
            return file_path
            
        except Exception as e:
            logger.error(f"Error exporting data to Excel: {str(e)}")
            return None
    
    def export_multiple_sheets(self, data_dict, filename):
        """
        Export multiple DataFrames to different sheets in a single Excel file
        
        Args:
            data_dict (dict): Dictionary of {sheet_name: DataFrame} pairs
            filename (str): Name of the Excel file (without path)
            
        Returns:
            str: Path to the saved Excel file
        """
        try:
            if not data_dict:
                logger.warning("No data to export to Excel")
                return None
            
            # Filter out empty DataFrames
            data_dict = {k: v for k, v in data_dict.items() if not v.empty}
            
            if not data_dict:
                logger.warning("All DataFrames are empty, nothing to export")
                return None
            
            # Ensure filename has .xlsx extension
            if not filename.endswith('.xlsx'):
                filename = f"{filename}.xlsx"
            
            # Full path to the Excel file
            file_path = os.path.join(self.output_dir, filename)
            
            # Create new Excel file with multiple sheets
            with pd.ExcelWriter(file_path, mode='w', engine='openpyxl') as writer:
                for sheet_name, df in data_dict.items():
                    df.to_excel(writer, sheet_name=sheet_name)
                
                logger.info(f"Created Excel file with {len(data_dict)} sheets: {file_path}")
            
            return file_path
            
        except Exception as e:
            logger.error(f"Error exporting multiple sheets to Excel: {str(e)}")
            return None
    
    def export_to_csv(self, data, filename):
        """
        Export data to a CSV file
        
        Args:
            data (pandas.DataFrame): DataFrame to export
            filename (str): Name of the CSV file (without path)
            
        Returns:
            str: Path to the saved CSV file
        """
        try:
            if data.empty:
                logger.warning("Cannot export empty data to CSV")
                return None
            
            # Ensure filename has .csv extension
            if not filename.endswith('.csv'):
                filename = f"{filename}.csv"
            
            # Full path to the CSV file
            file_path = os.path.join(self.output_dir, filename)
            
            # Export to CSV
            data.to_csv(file_path)
            logger.info(f"Created CSV file: {file_path}")
            
            return file_path
            
        except Exception as e:
            logger.error(f"Error exporting data to CSV: {str(e)}")
            return None
    
    def create_report(self, stock_data, indicators, metadata, filename=None):
        """
        Create a comprehensive report with stock data, technical indicators, and metadata
        
        Args:
            stock_data (pandas.DataFrame): DataFrame containing stock price data
            indicators (dict): Dictionary of {indicator_name: indicator_data} pairs
            metadata (dict): Dictionary of metadata about the report
            filename (str, optional): Name of the report file, default is generated from symbol and date
            
        Returns:
            str: Path to the saved report file
        """
        try:
            if stock_data.empty:
                logger.warning("Cannot create report with empty stock data")
                return None
            
            # Generate default filename if not provided
            if not filename:
                symbol = metadata.get('symbol', 'unknown')
                date_str = datetime.now().strftime('%Y%m%d')
                filename = f"{symbol}_report_{date_str}.xlsx"
            
            # Ensure filename has .xlsx extension
            if not filename.endswith('.xlsx'):
                filename = f"{filename}.xlsx"
            
            # Full path to the report file
            file_path = os.path.join(self.output_dir, filename)
            
            # Create report with multiple sheets
            with pd.ExcelWriter(file_path, mode='w', engine='openpyxl') as writer:
                # Write stock data to the main sheet
                stock_data.to_excel(writer, sheet_name='Price Data')
                
                # Write each indicator to a separate sheet
                for indicator_name, indicator_data in indicators.items():
                    if not isinstance(indicator_data, pd.DataFrame) and not isinstance(indicator_data, pd.Series):
                        # Skip non-DataFrame/Series data
                        continue
                        
                    if isinstance(indicator_data, pd.Series):
                        # Convert Series to DataFrame for consistent export
                        indicator_data = indicator_data.to_frame(name=indicator_name)
                    
                    # Check if data is empty
                    if indicator_data.empty:
                        continue
                    
                    # Export to sheet
                    indicator_data.to_excel(writer, sheet_name=indicator_name[:31])  # Max Excel sheet name length is 31
                
                # Create metadata sheet
                if metadata:
                    # Convert metadata to DataFrame
                    metadata_df = pd.DataFrame(list(metadata.items()), columns=['Property', 'Value'])
                    metadata_df.to_excel(writer, sheet_name='Metadata')
                
                logger.info(f"Created comprehensive report: {file_path}")
            
            return file_path
            
        except Exception as e:
            logger.error(f"Error creating report: {str(e)}")
            return None
    
    def list_files(self, filter_extension=None):
        """
        List all files in the exports directory
        
        Args:
            filter_extension (str, optional): Filter files by extension (e.g., '.xlsx', '.csv')
            
        Returns:
            list: List of file paths
        """
        try:
            files = []
            for file in os.listdir(self.output_dir):
                file_path = os.path.join(self.output_dir, file)
                
                # Check if it's a file (not a directory)
                if os.path.isfile(file_path):
                    # Filter by extension if specified
                    if filter_extension is None or file.endswith(filter_extension):
                        files.append(file_path)
            
            return files
            
        except Exception as e:
            logger.error(f"Error listing files: {str(e)}")
            return []