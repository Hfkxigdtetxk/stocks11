import pandas as pd
import requests
from datetime import datetime, timedelta
import time
import os
import json
from io import StringIO
import logging
from bs4 import BeautifulSoup

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class BSEIndiaScraper:
    """
    Scraper for retrieving data from the Bombay Stock Exchange (BSE)
    """
    
    def __init__(self):
        self.base_url = "https://api.bseindia.com"
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
            "Cache-Control": "max-age=0"
        }
        self.security_codes = {}  # Cache for BSE security codes

    def _get_security_code(self, symbol):
        """
        Helper function to get BSE security code for a symbol
        """
        if symbol in self.security_codes:
            return self.security_codes[symbol]
        
        # BSE uses numeric security codes, need to find the code for the symbol
        try:
            search_url = f"https://api.bseindia.com/BseIndiaAPI/api/StockTrading/w"
            params = {"flag": "1", "ltktme": "0", "symbol": symbol}
            
            response = requests.get(search_url, headers=self.headers, params=params)
            
            if response.status_code == 200:
                data = response.json()
                if data and 'SecurityCode' in data:
                    security_code = data['SecurityCode']
                    self.security_codes[symbol] = security_code
                    return security_code
            
            # If we couldn't find the security code, try alternative approach
            search_url = "https://www.bseindia.com/markets/equity/EQReports/MarketWatch.aspx"
            response = requests.get(search_url, headers=self.headers)
            
            if response.status_code == 200:
                soup = BeautifulSoup(response.text, 'html.parser')
                table = soup.find('table', {'id': 'tblMarketWatch'})
                
                if table:
                    rows = table.find_all('tr')
                    for row in rows:
                        cells = row.find_all('td')
                        if len(cells) > 1:
                            scrip_name = cells[0].text.strip()
                            if scrip_name.upper() == symbol.upper():
                                code_link = cells[0].find('a')
                                if code_link and 'href' in code_link.attrs:
                                    href = code_link['href']
                                    if 'ScripCode=' in href:
                                        security_code = href.split('ScripCode=')[1].split('&')[0]
                                        self.security_codes[symbol] = security_code
                                        return security_code
            
            # If still not found, return the symbol itself
            logger.warning(f"Could not find BSE security code for {symbol}, using symbol as fallback")
            return symbol
            
        except Exception as e:
            logger.error(f"Error getting BSE security code for {symbol}: {str(e)}")
            return symbol
    
    def get_price_data(self, symbol, start_date, end_date):
        """
        Retrieves historical price data for a given stock symbol
        
        Args:
            symbol (str): Stock symbol/ticker
            start_date (datetime.date): Start date for data retrieval
            end_date (datetime.date): End date for data retrieval
            
        Returns:
            pandas.DataFrame: DataFrame containing price data
        """
        try:
            logger.info(f"Fetching BSE price data for {symbol} from {start_date} to {end_date}")
            
            # Get BSE security code
            security_code = self._get_security_code(symbol)
            
            # Convert dates to strings in required format
            from_date = start_date.strftime('%Y%m%d')
            to_date = end_date.strftime('%Y%m%d')
            
            # Build URL for historical data
            url = f"{self.base_url}/BseIndiaAPI/api/StockPriceCSVDownload/w"
            params = {
                "pageType": "0",
                "rbType": "D",
                "Selectedio": "0",
                "fDate": from_date,
                "toDate": to_date,
                "scriptcode": security_code,
                "seriesid": "",
                "compareid": "",
                "frompg": "0"
            }
            
            # Add delay to avoid rate limiting
            time.sleep(1)
            
            response = requests.get(url, headers=self.headers, params=params)
            
            if response.status_code == 200:
                # BSE returns CSV data
                content = response.text
                if content and "SC_CODE" in content:
                    # Parse CSV data
                    csv_io = StringIO(content)
                    df = pd.read_csv(csv_io)
                    
                    # Rename columns to standard format
                    df.rename(columns={
                        'SC_CODE': 'Code',
                        'SC_NAME': 'Name',
                        'SC_GROUP': 'Group',
                        'SC_TYPE': 'Type',
                        'OPEN': 'Open',
                        'HIGH': 'High',
                        'LOW': 'Low',
                        'CLOSE': 'Close',
                        'LAST': 'Last',
                        'PREVCLOSE': 'PrevClose',
                        'NO_TRADES': 'Trades',
                        'NO_OF_SHRS': 'Volume',
                        'NET_TURNOV': 'Value',
                        'TDCLOINDI': 'Indicator',
                        'DATE1': 'Date'
                    }, inplace=True)
                    
                    # Convert date column to datetime
                    df['Date'] = pd.to_datetime(df['Date'], format='%d-%B-%Y')
                    df.set_index('Date', inplace=True)
                    
                    # Convert numeric columns
                    numeric_columns = ['Open', 'High', 'Low', 'Close', 'Volume', 'Value']
                    for col in numeric_columns:
                        if col in df.columns:
                            df[col] = pd.to_numeric(df[col], errors='coerce')
                    
                    # Sort by date in ascending order
                    df.sort_index(inplace=True)
                    
                    return df
                else:
                    logger.warning(f"No data available for {symbol} in the specified date range")
                    return pd.DataFrame()
            else:
                logger.error(f"Failed to retrieve data: Status code {response.status_code}")
                return pd.DataFrame()
                
        except Exception as e:
            logger.error(f"Error fetching price data for {symbol}: {str(e)}")
            # Try alternative approach using yfinance for BSE stocks
            try:
                import yfinance as yf
                ticker = f"{symbol}.BO"
                df = yf.download(ticker, start=start_date, end=end_date + timedelta(days=1))
                if not df.empty:
                    return df
                else:
                    return pd.DataFrame()
            except Exception as e2:
                logger.error(f"Error with alternative approach: {str(e2)}")
                return pd.DataFrame()
    
    def get_fii_dii_data(self, start_date, end_date):
        """
        Retrieves FII/DII data for the specified time period
        
        Args:
            start_date (datetime.date): Start date for data retrieval
            end_date (datetime.date): End date for data retrieval
            
        Returns:
            pandas.DataFrame: DataFrame containing FII/DII data
        """
        try:
            logger.info(f"Fetching BSE FII/DII data from {start_date} to {end_date}")
            
            all_data = []
            current_date = start_date
            
            while current_date <= end_date:
                date_str = current_date.strftime('%d%m%Y')
                
                # Add delay to avoid rate limiting
                time.sleep(1)
                
                # BSE FII/DII data endpoint
                url = f"https://www.bseindia.com/markets/MktRpt/MktRpt_fiiDII.aspx?Exch=B&Sel={date_str}"
                
                response = requests.get(url, headers=self.headers)
                
                if response.status_code == 200:
                    soup = BeautifulSoup(response.text, 'html.parser')
                    
                    # BSE provides FII/DII data in tables
                    tables = soup.find_all('table', {'class': 'tblfont'})
                    
                    fii_data = {}
                    dii_data = {}
                    
                    for table in tables:
                        # Check if this is the FII or DII table
                        table_caption = table.find_previous('table')
                        if table_caption:
                            caption_text = table_caption.text.strip()
                            
                            rows = table.find_all('tr')
                            if len(rows) > 1:
                                data_cells = rows[1].find_all('td')
                                
                                if len(data_cells) >= 9:
                                    buy_value = data_cells[6].text.strip().replace(',', '')
                                    sell_value = data_cells[8].text.strip().replace(',', '')
                                    
                                    if 'FII' in caption_text:
                                        fii_data['Buy'] = float(buy_value) if buy_value else 0
                                        fii_data['Sell'] = float(sell_value) if sell_value else 0
                                    elif 'DII' in caption_text:
                                        dii_data['Buy'] = float(buy_value) if buy_value else 0
                                        dii_data['Sell'] = float(sell_value) if sell_value else 0
                    
                    if fii_data or dii_data:
                        data_entry = {
                            'Date': current_date,
                            'FII Buy': fii_data.get('Buy', 0),
                            'FII Sell': fii_data.get('Sell', 0),
                            'DII Buy': dii_data.get('Buy', 0),
                            'DII Sell': dii_data.get('Sell', 0)
                        }
                        all_data.append(data_entry)
                
                # Move to next day
                current_date += timedelta(days=1)
            
            if all_data:
                df = pd.DataFrame(all_data)
                df.set_index('Date', inplace=True)
                
                # Calculate net positions
                df['FII Net'] = df['FII Buy'] - df['FII Sell']
                df['DII Net'] = df['DII Buy'] - df['DII Sell']
                
                return df
            else:
                logger.warning("No FII/DII data found for the specified date range")
                return pd.DataFrame()
            
        except Exception as e:
            logger.error(f"Error fetching FII/DII data: {str(e)}")
            return pd.DataFrame()
    
    def get_block_deals(self, symbol, start_date, end_date):
        """
        Retrieves block deals data for a given stock symbol
        
        Args:
            symbol (str): Stock symbol/ticker
            start_date (datetime.date): Start date for data retrieval
            end_date (datetime.date): End date for data retrieval
            
        Returns:
            pandas.DataFrame: DataFrame containing block deals data
        """
        try:
            logger.info(f"Fetching BSE block deals for {symbol} from {start_date} to {end_date}")
            
            # Get BSE security code
            security_code = self._get_security_code(symbol)
            
            all_deals = []
            current_date = start_date
            
            while current_date <= end_date:
                date_str = current_date.strftime('%Y%m%d')
                
                # Add delay to avoid rate limiting
                time.sleep(1)
                
                # BSE block deals API endpoint
                url = f"https://api.bseindia.com/BseIndiaAPI/api/BlockDeals/w"
                params = {
                    "date1": date_str,
                    "date2": date_str,
                    "scripcode": security_code
                }
                
                response = requests.get(url, headers=self.headers, params=params)
                
                if response.status_code == 200:
                    data = response.json()
                    
                    if data and 'Table' in data and data['Table']:
                        for deal in data['Table']:
                            deal['Date'] = current_date
                            all_deals.append(deal)
                
                # Move to next day
                current_date += timedelta(days=1)
            
            if all_deals:
                df = pd.DataFrame(all_deals)
                
                # Rename columns to standard format
                df.rename(columns={
                    'Client_Name': 'Client Name',
                    'Script_Name': 'Symbol',
                    'Quantity': 'Quantity',
                    'Rate': 'Price',
                    'Value': 'Value',
                    'Deal': 'Transaction Type'
                }, inplace=True)
                
                # Convert date to datetime and set as index
                df['Date'] = pd.to_datetime(df['Date'])
                df.set_index('Date', inplace=True)
                
                # Convert numeric columns
                numeric_columns = ['Quantity', 'Price', 'Value']
                for col in numeric_columns:
                    if col in df.columns:
                        df[col] = pd.to_numeric(df[col], errors='coerce')
                
                return df
            else:
                logger.warning(f"No block deals found for {symbol} in the specified date range")
                return pd.DataFrame()
            
        except Exception as e:
            logger.error(f"Error fetching block deals data for {symbol}: {str(e)}")
            return pd.DataFrame()
    
    def get_bulk_deals(self, symbol, start_date, end_date):
        """
        Retrieves bulk deals data for a given stock symbol
        
        Args:
            symbol (str): Stock symbol/ticker
            start_date (datetime.date): Start date for data retrieval
            end_date (datetime.date): End date for data retrieval
            
        Returns:
            pandas.DataFrame: DataFrame containing bulk deals data
        """
        try:
            logger.info(f"Fetching BSE bulk deals for {symbol} from {start_date} to {end_date}")
            
            # Get BSE security code
            security_code = self._get_security_code(symbol)
            
            all_deals = []
            current_date = start_date
            
            while current_date <= end_date:
                date_str = current_date.strftime('%Y%m%d')
                
                # Add delay to avoid rate limiting
                time.sleep(1)
                
                # BSE bulk deals API endpoint
                url = f"https://api.bseindia.com/BseIndiaAPI/api/BulkDeals/w"
                params = {
                    "date1": date_str,
                    "date2": date_str,
                    "scripcode": security_code
                }
                
                response = requests.get(url, headers=self.headers, params=params)
                
                if response.status_code == 200:
                    data = response.json()
                    
                    if data and 'Table' in data and data['Table']:
                        for deal in data['Table']:
                            deal['Date'] = current_date
                            all_deals.append(deal)
                
                # Move to next day
                current_date += timedelta(days=1)
            
            if all_deals:
                df = pd.DataFrame(all_deals)
                
                # Rename columns to standard format
                df.rename(columns={
                    'Client_Name': 'Client Name',
                    'Script_Name': 'Symbol',
                    'Quantity': 'Quantity',
                    'Rate': 'Price',
                    'Value': 'Value',
                    'Deal': 'Transaction Type'
                }, inplace=True)
                
                # Convert date to datetime and set as index
                df['Date'] = pd.to_datetime(df['Date'])
                df.set_index('Date', inplace=True)
                
                # Convert numeric columns
                numeric_columns = ['Quantity', 'Price', 'Value']
                for col in numeric_columns:
                    if col in df.columns:
                        df[col] = pd.to_numeric(df[col], errors='coerce')
                
                return df
            else:
                logger.warning(f"No bulk deals found for {symbol} in the specified date range")
                return pd.DataFrame()
            
        except Exception as e:
            logger.error(f"Error fetching bulk deals data for {symbol}: {str(e)}")
            return pd.DataFrame()
    
    def get_short_selling_data(self, symbol, start_date, end_date):
        """
        Retrieves short selling data for a given stock symbol
        
        Args:
            symbol (str): Stock symbol/ticker
            start_date (datetime.date): Start date for data retrieval
            end_date (datetime.date): End date for data retrieval
            
        Returns:
            pandas.DataFrame: DataFrame containing short selling data
        """
        try:
            logger.info(f"Fetching BSE short selling data for {symbol} from {start_date} to {end_date}")
            
            # BSE doesn't provide direct API for short selling data
            # Using similar approach as with NSE scraper
            url = "https://www.sebi.gov.in/sebiweb/other/OtherAction.do?doRecognisedFpi=yes&intmId=42"
            
            response = requests.get(url, headers=self.headers)
            
            if response.status_code == 200:
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # This is a simplified approach as SEBI's website structure may change
                # Look for tables containing short selling data
                tables = soup.find_all('table')
                
                short_data = []
                
                for table in tables:
                    rows = table.find_all('tr')
                    for row in rows:
                        cells = row.find_all('td')
                        if len(cells) >= 4:
                            # Check if this row contains our symbol
                            if symbol in cells[0].text:
                                try:
                                    date_text = cells[1].text.strip()
                                    date = datetime.strptime(date_text, '%d-%m-%Y').date()
                                    
                                    if start_date <= date <= end_date:
                                        short_data.append({
                                            'Date': date,
                                            'Symbol': symbol,
                                            'Short Volume': float(cells[2].text.strip().replace(',', '')),
                                            'Short Value': float(cells[3].text.strip().replace(',', ''))
                                        })
                                except (ValueError, IndexError):
                                    continue
                
                if short_data:
                    df = pd.DataFrame(short_data)
                    df.set_index('Date', inplace=True)
                    
                    # Calculate short ratio if volume data is available
                    if 'Short Volume' in df.columns:
                        # Get the daily volume from price data
                        price_data = self.get_price_data(symbol, start_date, end_date)
                        if not price_data.empty and 'Volume' in price_data.columns:
                            # Merge datasets
                            df = df.join(price_data[['Volume']], how='left')
                            # Calculate short ratio
                            df['Short Ratio'] = df['Short Volume'] / df['Volume']
                    
                    return df
                else:
                    logger.warning(f"No short selling data found for {symbol}")
                    # Create an empty dataframe
                    return pd.DataFrame()
            else:
                logger.error(f"Failed to retrieve short selling data: Status code {response.status_code}")
                return pd.DataFrame()
            
        except Exception as e:
            logger.error(f"Error fetching short selling data for {symbol}: {str(e)}")
            return pd.DataFrame()
