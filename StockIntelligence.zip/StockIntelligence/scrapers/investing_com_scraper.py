import pandas as pd
from datetime import datetime, timedelta
import time
import os
import logging
import requests
from bs4 import BeautifulSoup
import trafilatura
import re
import json

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class InvestingComScraper:
    """
    Scraper for retrieving data from Investing.com
    Provides global market data, forex, commodities, indices, and crypto
    """
    
    def __init__(self):
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
            "Cache-Control": "max-age=0"
        }
        self.base_url = "https://www.investing.com"
    
    def _search_symbol(self, symbol):
        """
        Search for a symbol on Investing.com to get its internal ID
        
        Args:
            symbol (str): Symbol/ticker/name to search for
            
        Returns:
            dict: Dictionary with symbol information including pair_id
        """
        try:
            search_url = f"{self.base_url}/search/?q={symbol}"
            
            # Get the search page
            response = requests.get(search_url, headers=self.headers)
            
            if response.status_code != 200:
                logger.warning(f"Failed to search for {symbol}: Status code {response.status_code}")
                return None
            
            # Use trafilatura to extract text content from the HTML
            downloaded = response.text
            extracted_text = trafilatura.extract(downloaded)
            
            # Parse with BeautifulSoup for more detailed extraction
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Find search results
            search_results = soup.select('.js-inner-all-results-quote-item')
            
            if not search_results:
                logger.warning(f"No search results found for {symbol}")
                return None
            
            # Extract the first result that looks like a stock/equity
            for result in search_results:
                # Extract pair ID from data attribute
                pair_id = result.get('data-pairid')
                if not pair_id:
                    continue
                
                # Extract symbol name
                name_elem = result.select_one('.second')
                name = name_elem.text.strip() if name_elem else ''
                
                # Extract exchange info
                exchange_elem = result.select_one('.third')
                exchange = exchange_elem.text.strip() if exchange_elem else ''
                
                # Extract type (stock, index, etc.)
                type_elem = result.select_one('.fourth')
                type_text = type_elem.text.strip() if type_elem else ''
                
                # Return the first valid result
                return {
                    'pair_id': pair_id,
                    'name': name,
                    'exchange': exchange,
                    'type': type_text
                }
            
            logger.warning(f"No suitable result found for {symbol}")
            return None
            
        except Exception as e:
            logger.error(f"Error searching for {symbol}: {str(e)}")
            return None
    
    def get_price_data(self, symbol, start_date, end_date):
        """
        Retrieves historical price data for a given symbol
        
        Args:
            symbol (str): Symbol/ticker to search for
            start_date (datetime.date): Start date for data retrieval
            end_date (datetime.date): End date for data retrieval
            
        Returns:
            pandas.DataFrame: DataFrame containing price data
        """
        try:
            logger.info(f"Fetching Investing.com price data for {symbol} from {start_date} to {end_date}")
            
            # First search for the symbol to get its ID
            symbol_info = self._search_symbol(symbol)
            
            if not symbol_info or 'pair_id' not in symbol_info:
                logger.warning(f"Could not find pair ID for {symbol}")
                return pd.DataFrame()
            
            pair_id = symbol_info['pair_id']
            
            # Format dates as required by Investing.com API
            start_timestamp = int(datetime.combine(start_date, datetime.min.time()).timestamp())
            end_timestamp = int(datetime.combine(end_date, datetime.max.time()).timestamp())
            
            # Investing.com historical data API endpoint
            url = f"{self.base_url}/instruments/HistoricalDataAjax"
            
            payload = {
                "curr_id": pair_id,
                "smlID": "1159963",
                "header": f"{symbol} Historical Data",
                "st_date": start_date.strftime('%m/%d/%Y'),
                "end_date": end_date.strftime('%m/%d/%Y'),
                "interval_sec": "Daily",
                "sort_col": "date",
                "sort_ord": "DESC",
                "action": "historical_data"
            }
            
            # Make the request
            response = requests.post(url, headers=self.headers, data=payload)
            
            if response.status_code != 200:
                logger.warning(f"Failed to get historical data: Status code {response.status_code}")
                return pd.DataFrame()
            
            # Parse the HTML response to extract the data table
            soup = BeautifulSoup(response.text, 'html.parser')
            table = soup.select_one('#curr_table')
            
            if not table:
                logger.warning("No data table found in response")
                return pd.DataFrame()
            
            # Extract data from the table
            data = []
            rows = table.select('tbody tr')
            
            for row in rows:
                cells = row.select('td')
                if len(cells) < 6:  # Ensure we have enough cells
                    continue
                
                try:
                    # Parse the date cell
                    date_str = cells[0].text.strip()
                    date = datetime.strptime(date_str, '%b %d, %Y')
                    
                    # Parse price data cells (remove commas from numbers)
                    price_open = float(cells[1].text.replace(',', ''))
                    price_high = float(cells[2].text.replace(',', ''))
                    price_low = float(cells[3].text.replace(',', ''))
                    price_close = float(cells[4].text.replace(',', ''))
                    
                    # Parse volume cell (handle K, M, B suffixes)
                    volume_str = cells[5].text.strip()
                    volume_val = volume_str.replace(',', '')
                    
                    # Handle suffixes like K, M, B
                    volume_multiplier = 1
                    if volume_val.endswith('K'):
                        volume_multiplier = 1000
                        volume_val = volume_val[:-1]
                    elif volume_val.endswith('M'):
                        volume_multiplier = 1000000
                        volume_val = volume_val[:-1]
                    elif volume_val.endswith('B'):
                        volume_multiplier = 1000000000
                        volume_val = volume_val[:-1]
                    
                    try:
                        volume = float(volume_val) * volume_multiplier
                    except ValueError:
                        volume = 0
                    
                    # Add the row data
                    data.append({
                        'Date': date,
                        'Open': price_open,
                        'High': price_high,
                        'Low': price_low,
                        'Close': price_close,
                        'Volume': volume
                    })
                except Exception as e:
                    logger.warning(f"Error parsing row: {str(e)}")
                    continue
            
            if not data:
                logger.warning("No data extracted from table")
                return pd.DataFrame()
            
            # Create a DataFrame from the extracted data
            df = pd.DataFrame(data)
            df.set_index('Date', inplace=True)
            df.sort_index(inplace=True)  # Ensure dates are in ascending order
            
            return df
            
        except Exception as e:
            logger.error(f"Error fetching price data for {symbol}: {str(e)}")
            return pd.DataFrame()
    
    def get_economic_calendar(self, start_date, end_date, country=None):
        """
        Retrieves economic calendar events for the specified time period
        
        Args:
            start_date (datetime.date): Start date for data retrieval
            end_date (datetime.date): End date for data retrieval
            country (str, optional): Filter by country (e.g., 'united-states', 'india')
            
        Returns:
            pandas.DataFrame: DataFrame containing economic events
        """
        try:
            logger.info(f"Fetching economic calendar from {start_date} to {end_date}")
            
            # Format dates as required by Investing.com
            start_str = start_date.strftime('%Y-%m-%d')
            end_str = end_date.strftime('%Y-%m-%d')
            
            # Build URL based on filters
            calendar_url = f"{self.base_url}/economic-calendar/"
            if country:
                calendar_url += f"?country={country}"
            
            # Add date parameters
            if '?' in calendar_url:
                calendar_url += f"&dateFrom={start_str}&dateTo={end_str}"
            else:
                calendar_url += f"?dateFrom={start_str}&dateTo={end_str}"
            
            # Make the request
            response = requests.get(calendar_url, headers=self.headers)
            
            if response.status_code != 200:
                logger.warning(f"Failed to get economic calendar: Status code {response.status_code}")
                return pd.DataFrame()
            
            # Extract data using trafilatura
            downloaded = response.text
            extracted_text = trafilatura.extract(downloaded)
            
            # Parse with BeautifulSoup for table data
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Find the economic calendar data
            events = []
            
            # Look for event rows in the calendar
            event_rows = soup.select('.js-event-item')
            
            for row in event_rows:
                try:
                    # Extract event time
                    time_elem = row.select_one('.js-date')
                    time_str = time_elem.text.strip() if time_elem else ''
                    
                    # Extract event date
                    date_attr = row.get('data-event-datetime')
                    date_str = date_attr.split(' ')[0] if date_attr else ''
                    
                    # Combine date and time
                    if date_str and time_str:
                        try:
                            event_datetime = datetime.strptime(f"{date_str} {time_str}", '%Y/%m/%d %H:%M')
                        except ValueError:
                            # Try alternative format
                            try:
                                event_datetime = datetime.strptime(f"{date_str} {time_str}", '%Y-%m-%d %H:%M')
                            except ValueError:
                                event_datetime = None
                    else:
                        event_datetime = None
                    
                    # Extract event country
                    country_elem = row.select_one('.flagCur')
                    country = country_elem.get('title') if country_elem else ''
                    
                    # Extract event name
                    event_elem = row.select_one('.event')
                    event_name = event_elem.text.strip() if event_elem else ''
                    
                    # Extract importance
                    importance_elem = row.select_one('.importance')
                    importance = importance_elem.text.strip() if importance_elem else ''
                    
                    # Extract actual value
                    actual_elem = row.select_one('.actual')
                    actual = actual_elem.text.strip() if actual_elem else ''
                    
                    # Extract forecast value
                    forecast_elem = row.select_one('.forecast')
                    forecast = forecast_elem.text.strip() if forecast_elem else ''
                    
                    # Extract previous value
                    previous_elem = row.select_one('.previous')
                    previous = previous_elem.text.strip() if previous_elem else ''
                    
                    # Add the event data
                    events.append({
                        'DateTime': event_datetime,
                        'Country': country,
                        'Event': event_name,
                        'Importance': importance,
                        'Actual': actual,
                        'Forecast': forecast,
                        'Previous': previous
                    })
                    
                except Exception as e:
                    logger.warning(f"Error parsing event row: {str(e)}")
                    continue
            
            if not events:
                logger.warning("No economic events found")
                return pd.DataFrame()
            
            # Create a DataFrame from the extracted events
            df = pd.DataFrame(events)
            
            # Set datetime as index if available
            if 'DateTime' in df.columns and not df['DateTime'].isna().all():
                df.set_index('DateTime', inplace=True)
                df.sort_index(inplace=True)  # Ensure dates are in ascending order
            
            return df
            
        except Exception as e:
            logger.error(f"Error fetching economic calendar: {str(e)}")
            return pd.DataFrame()
    
    def get_forex_data(self, symbol, start_date, end_date):
        """
        Retrieves forex data for a given currency pair
        
        Args:
            symbol (str): Forex pair (e.g., 'EUR/USD', 'USD/JPY')
            start_date (datetime.date): Start date for data retrieval
            end_date (datetime.date): End date for data retrieval
            
        Returns:
            pandas.DataFrame: DataFrame containing forex data
        """
        try:
            logger.info(f"Fetching forex data for {symbol} from {start_date} to {end_date}")
            
            # Use the same method as get_price_data but search for the forex pair
            return self.get_price_data(symbol, start_date, end_date)
            
        except Exception as e:
            logger.error(f"Error fetching forex data for {symbol}: {str(e)}")
            return pd.DataFrame()
    
    def get_commodity_data(self, commodity, start_date, end_date):
        """
        Retrieves commodity price data
        
        Args:
            commodity (str): Commodity name (e.g., 'Gold', 'Crude Oil', 'Natural Gas')
            start_date (datetime.date): Start date for data retrieval
            end_date (datetime.date): End date for data retrieval
            
        Returns:
            pandas.DataFrame: DataFrame containing commodity price data
        """
        try:
            logger.info(f"Fetching commodity data for {commodity} from {start_date} to {end_date}")
            
            # Use the same method as get_price_data but search for the commodity
            return self.get_price_data(commodity, start_date, end_date)
            
        except Exception as e:
            logger.error(f"Error fetching commodity data for {commodity}: {str(e)}")
            return pd.DataFrame()
    
    def get_index_data(self, index_name, start_date, end_date):
        """
        Retrieves index price data
        
        Args:
            index_name (str): Index name (e.g., 'S&P 500', 'Dow Jones', 'Nifty 50')
            start_date (datetime.date): Start date for data retrieval
            end_date (datetime.date): End date for data retrieval
            
        Returns:
            pandas.DataFrame: DataFrame containing index price data
        """
        try:
            logger.info(f"Fetching index data for {index_name} from {start_date} to {end_date}")
            
            # Use the same method as get_price_data but search for the index
            return self.get_price_data(index_name, start_date, end_date)
            
        except Exception as e:
            logger.error(f"Error fetching index data for {index_name}: {str(e)}")
            return pd.DataFrame()
    
    def get_crypto_data(self, crypto, start_date, end_date):
        """
        Retrieves cryptocurrency price data
        
        Args:
            crypto (str): Cryptocurrency name or symbol (e.g., 'Bitcoin', 'BTC/USD')
            start_date (datetime.date): Start date for data retrieval
            end_date (datetime.date): End date for data retrieval
            
        Returns:
            pandas.DataFrame: DataFrame containing cryptocurrency price data
        """
        try:
            logger.info(f"Fetching crypto data for {crypto} from {start_date} to {end_date}")
            
            # Use the same method as get_price_data but search for the cryptocurrency
            return self.get_price_data(crypto, start_date, end_date)
            
        except Exception as e:
            logger.error(f"Error fetching crypto data for {crypto}: {str(e)}")
            return pd.DataFrame()
    
    # Placeholder methods to maintain API compatibility with other scrapers
    def get_fii_dii_data(self, start_date, end_date):
        logger.warning("Investing.com doesn't provide FII/DII data. Use NSE or BSE scraper instead.")
        return pd.DataFrame()
    
    def get_block_deals(self, symbol, start_date, end_date):
        logger.warning("Investing.com doesn't provide block deals data. Use NSE or BSE scraper instead.")
        return pd.DataFrame()
    
    def get_bulk_deals(self, symbol, start_date, end_date):
        logger.warning("Investing.com doesn't provide bulk deals data. Use NSE or BSE scraper instead.")
        return pd.DataFrame()
    
    def get_short_selling_data(self, symbol, start_date, end_date):
        logger.warning("Investing.com doesn't provide detailed short selling data.")
        return pd.DataFrame()