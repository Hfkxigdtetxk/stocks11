import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def calculate_sma(price_data, period):
    """
    Calculate Simple Moving Average for the given price data
    
    Args:
        price_data (pandas.DataFrame): DataFrame containing price data with 'Close' column
        period (int): Period for SMA calculation
        
    Returns:
        pandas.Series: Series containing SMA values
    """
    try:
        if price_data.empty or 'Close' not in price_data.columns:
            logger.warning("Cannot calculate SMA: price data is empty or missing 'Close' column")
            return pd.Series()
        
        sma = price_data['Close'].rolling(window=period).mean()
        return sma
    except Exception as e:
        logger.error(f"Error calculating SMA: {str(e)}")
        return pd.Series()

def calculate_ema(price_data, period):
    """
    Calculate Exponential Moving Average for the given price data
    
    Args:
        price_data (pandas.DataFrame): DataFrame containing price data with 'Close' column
        period (int): Period for EMA calculation
        
    Returns:
        pandas.Series: Series containing EMA values
    """
    try:
        if price_data.empty or 'Close' not in price_data.columns:
            logger.warning("Cannot calculate EMA: price data is empty or missing 'Close' column")
            return pd.Series()
        
        ema = price_data['Close'].ewm(span=period, adjust=False).mean()
        return ema
    except Exception as e:
        logger.error(f"Error calculating EMA: {str(e)}")
        return pd.Series()

def calculate_rsi(price_data, period=14):
    """
    Calculate Relative Strength Index for the given price data
    
    Args:
        price_data (pandas.DataFrame): DataFrame containing price data with 'Close' column
        period (int): Period for RSI calculation, default is 14
        
    Returns:
        pandas.Series: Series containing RSI values
    """
    try:
        if price_data.empty or 'Close' not in price_data.columns:
            logger.warning("Cannot calculate RSI: price data is empty or missing 'Close' column")
            return pd.Series()
        
        # Calculate price changes
        delta = price_data['Close'].diff()
        
        # Separate gains and losses
        gain = delta.where(delta > 0, 0)
        loss = -delta.where(delta < 0, 0)
        
        # Calculate average gain and loss
        avg_gain = gain.rolling(window=period).mean()
        avg_loss = loss.rolling(window=period).mean()
        
        # Calculate RS
        rs = avg_gain / avg_loss
        
        # Calculate RSI
        rsi = 100 - (100 / (1 + rs))
        
        return rsi
    except Exception as e:
        logger.error(f"Error calculating RSI: {str(e)}")
        return pd.Series()

def calculate_macd(price_data, fast_period=12, slow_period=26, signal_period=9):
    """
    Calculate Moving Average Convergence Divergence for the given price data
    
    Args:
        price_data (pandas.DataFrame): DataFrame containing price data with 'Close' column
        fast_period (int): Period for fast EMA, default is 12
        slow_period (int): Period for slow EMA, default is 26
        signal_period (int): Period for signal line, default is 9
        
    Returns:
        tuple: (macd, signal, histogram) as pandas Series
    """
    try:
        if price_data.empty or 'Close' not in price_data.columns:
            logger.warning("Cannot calculate MACD: price data is empty or missing 'Close' column")
            return pd.Series(), pd.Series(), pd.Series()
        
        # Calculate EMAs
        fast_ema = price_data['Close'].ewm(span=fast_period, adjust=False).mean()
        slow_ema = price_data['Close'].ewm(span=slow_period, adjust=False).mean()
        
        # Calculate MACD line
        macd = fast_ema - slow_ema
        
        # Calculate signal line
        signal = macd.ewm(span=signal_period, adjust=False).mean()
        
        # Calculate histogram
        histogram = macd - signal
        
        return macd, signal, histogram
    except Exception as e:
        logger.error(f"Error calculating MACD: {str(e)}")
        return pd.Series(), pd.Series(), pd.Series()

def calculate_bollinger_bands(price_data, period=20, num_std=2):
    """
    Calculate Bollinger Bands for the given price data
    
    Args:
        price_data (pandas.DataFrame): DataFrame containing price data with 'Close' column
        period (int): Period for moving average, default is 20
        num_std (int): Number of standard deviations, default is 2
        
    Returns:
        tuple: (upper_band, middle_band, lower_band) as pandas Series
    """
    try:
        if price_data.empty or 'Close' not in price_data.columns:
            logger.warning("Cannot calculate Bollinger Bands: price data is empty or missing 'Close' column")
            return pd.Series(), pd.Series(), pd.Series()
        
        # Calculate middle band (SMA)
        middle_band = price_data['Close'].rolling(window=period).mean()
        
        # Calculate standard deviation
        std = price_data['Close'].rolling(window=period).std()
        
        # Calculate upper and lower bands
        upper_band = middle_band + (std * num_std)
        lower_band = middle_band - (std * num_std)
        
        return upper_band, middle_band, lower_band
    except Exception as e:
        logger.error(f"Error calculating Bollinger Bands: {str(e)}")
        return pd.Series(), pd.Series(), pd.Series()

def combine_data_sources(nse_data, bse_data, google_data, method='average'):
    """
    Combine data from multiple sources into a single DataFrame
    
    Args:
        nse_data (pandas.DataFrame): Data from NSE
        bse_data (pandas.DataFrame): Data from BSE
        google_data (pandas.DataFrame): Data from Google Finance
        method (str): Method to combine data ('average', 'nse_priority', 'bse_priority', 'google_priority')
        
    Returns:
        pandas.DataFrame: Combined data
    """
    try:
        # Check if all dataframes are empty
        if nse_data.empty and bse_data.empty and google_data.empty:
            logger.warning("All input dataframes are empty, cannot combine data")
            return pd.DataFrame()
        
        # Create a list of non-empty dataframes
        dfs = []
        if not nse_data.empty:
            dfs.append(('NSE', nse_data))
        if not bse_data.empty:
            dfs.append(('BSE', bse_data))
        if not google_data.empty:
            dfs.append(('Google', google_data))
        
        # If only one dataframe is non-empty, return it
        if len(dfs) == 1:
            logger.info(f"Only {dfs[0][0]} data is available, using it as is")
            return dfs[0][1]
        
        # Handle different combination methods
        if method == 'nse_priority' and not nse_data.empty:
            return nse_data
        elif method == 'bse_priority' and not bse_data.empty:
            return bse_data
        elif method == 'google_priority' and not google_data.empty:
            return google_data
        else:  # Default to average method
            # Get all unique dates across all dataframes
            all_dates = set()
            for _, df in dfs:
                all_dates.update(df.index)
            
            # Create a combined dataframe with all dates
            combined_df = pd.DataFrame(index=sorted(all_dates))
            
            # For each column that exists in any of the dataframes
            all_columns = set()
            for _, df in dfs:
                all_columns.update(df.columns)
            
            for column in all_columns:
                # Get this column from each dataframe that has it
                values = []
                for _, df in dfs:
                    if column in df.columns:
                        # Reindex to match all_dates
                        values.append(df[column].reindex(combined_df.index))
                
                # If no dataframe has this column, skip it
                if not values:
                    continue
                
                # Calculate average, ignoring NaN values
                combined_df[column] = pd.concat(values, axis=1).mean(axis=1, skipna=True)
            
            return combined_df
            
    except Exception as e:
        logger.error(f"Error combining data sources: {str(e)}")
        # Return the first non-empty dataframe as a fallback
        if not nse_data.empty:
            return nse_data
        elif not bse_data.empty:
            return bse_data
        elif not google_data.empty:
            return google_data
        else:
            return pd.DataFrame()

def calculate_volume_ma(price_data, period=20):
    """
    Calculate Volume Moving Average for the given price data
    
    Args:
        price_data (pandas.DataFrame): DataFrame containing price data with 'Volume' column
        period (int): Period for volume MA calculation, default is 20
        
    Returns:
        pandas.Series: Series containing Volume MA values
    """
    try:
        if price_data.empty or 'Volume' not in price_data.columns:
            logger.warning("Cannot calculate Volume MA: price data is empty or missing 'Volume' column")
            return pd.Series()
        
        volume_ma = price_data['Volume'].rolling(window=period).mean()
        return volume_ma
    except Exception as e:
        logger.error(f"Error calculating Volume MA: {str(e)}")
        return pd.Series()

def calculate_obv(price_data):
    """
    Calculate On-Balance Volume (OBV) for the given price data
    
    Args:
        price_data (pandas.DataFrame): DataFrame containing price data with 'Close' and 'Volume' columns
        
    Returns:
        pandas.Series: Series containing OBV values
    """
    try:
        if price_data.empty or 'Close' not in price_data.columns or 'Volume' not in price_data.columns:
            logger.warning("Cannot calculate OBV: price data is empty or missing required columns")
            return pd.Series()
        
        # Calculate daily price change
        price_change = price_data['Close'].diff()
        
        # Create OBV series
        obv = pd.Series(index=price_data.index)
        obv.iloc[0] = price_data['Volume'].iloc[0]  # Set first value to first volume
        
        # Calculate OBV
        for i in range(1, len(price_data)):
            if price_change.iloc[i] > 0:  # Price up, add volume
                obv.iloc[i] = obv.iloc[i-1] + price_data['Volume'].iloc[i]
            elif price_change.iloc[i] < 0:  # Price down, subtract volume
                obv.iloc[i] = obv.iloc[i-1] - price_data['Volume'].iloc[i]
            else:  # Price unchanged, OBV remains the same
                obv.iloc[i] = obv.iloc[i-1]
        
        return obv
    except Exception as e:
        logger.error(f"Error calculating OBV: {str(e)}")
        return pd.Series()

def calculate_vwap(price_data):
    """
    Calculate Volume-Weighted Average Price (VWAP) for the given price data
    
    Args:
        price_data (pandas.DataFrame): DataFrame containing price data with OHLC and 'Volume' columns
        
    Returns:
        pandas.Series: Series containing VWAP values
    """
    try:
        required_columns = ['Open', 'High', 'Low', 'Close', 'Volume']
        if price_data.empty or not all(col in price_data.columns for col in required_columns):
            logger.warning("Cannot calculate VWAP: price data is empty or missing required columns")
            return pd.Series()
        
        # Calculate typical price: (High + Low + Close) / 3
        typical_price = (price_data['High'] + price_data['Low'] + price_data['Close']) / 3
        
        # Calculate VWAP: sum(typical_price * volume) / sum(volume)
        vwap = (typical_price * price_data['Volume']).cumsum() / price_data['Volume'].cumsum()
        
        return vwap
    except Exception as e:
        logger.error(f"Error calculating VWAP: {str(e)}")
        return pd.Series()

def calculate_volume_profile(price_data, bins=10):
    """
    Calculate Volume Profile (Volume by Price) for the given price data
    
    Args:
        price_data (pandas.DataFrame): DataFrame containing price data with 'Close' and 'Volume' columns
        bins (int): Number of price bins to divide the range into, default is 10
        
    Returns:
        pandas.DataFrame: DataFrame containing volume profile data
    """
    try:
        if price_data.empty or 'Close' not in price_data.columns or 'Volume' not in price_data.columns:
            logger.warning("Cannot calculate Volume Profile: price data is empty or missing required columns")
            return pd.DataFrame()
        
        # Get price range
        price_min = price_data['Close'].min()
        price_max = price_data['Close'].max()
        
        # Create price bins
        price_bins = np.linspace(price_min, price_max, bins + 1)
        bin_centers = (price_bins[:-1] + price_bins[1:]) / 2
        
        # Calculate volume per bin
        vol_profile = np.zeros(bins)
        for i in range(len(price_data)):
            bin_idx = np.digitize(price_data['Close'].iloc[i], price_bins) - 1
            if 0 <= bin_idx < bins:  # Ensure index is valid
                vol_profile[bin_idx] += price_data['Volume'].iloc[i]
        
        # Create result DataFrame
        result = pd.DataFrame({
            'Price': bin_centers,
            'Volume': vol_profile
        })
        
        return result
    except Exception as e:
        logger.error(f"Error calculating Volume Profile: {str(e)}")
        return pd.DataFrame()

def calculate_money_flow_index(price_data, period=14):
    """
    Calculate Money Flow Index (MFI) for the given price data
    
    Args:
        price_data (pandas.DataFrame): DataFrame containing price data with OHLC and 'Volume' columns
        period (int): Period for MFI calculation, default is 14
        
    Returns:
        pandas.Series: Series containing MFI values (0-100)
    """
    try:
        required_columns = ['High', 'Low', 'Close', 'Volume']
        if price_data.empty or not all(col in price_data.columns for col in required_columns):
            logger.warning("Cannot calculate MFI: price data is empty or missing required columns")
            return pd.Series()
        
        # Calculate typical price
        typical_price = (price_data['High'] + price_data['Low'] + price_data['Close']) / 3
        
        # Calculate raw money flow
        raw_money_flow = typical_price * price_data['Volume']
        
        # Calculate money flow direction
        price_change = typical_price.diff()
        positive_flow = pd.Series(0, index=price_data.index)
        negative_flow = pd.Series(0, index=price_data.index)
        
        positive_flow[price_change > 0] = raw_money_flow[price_change > 0]
        negative_flow[price_change < 0] = raw_money_flow[price_change < 0]
        
        # Calculate positive and negative money flow sums over period
        positive_flow_sum = positive_flow.rolling(window=period).sum()
        negative_flow_sum = negative_flow.rolling(window=period).sum()
        
        # Calculate money flow ratio and MFI
        money_ratio = positive_flow_sum / negative_flow_sum
        mfi = 100 - (100 / (1 + money_ratio))
        
        return mfi
    except Exception as e:
        logger.error(f"Error calculating Money Flow Index: {str(e)}")
        return pd.Series()

def calculate_atr(price_data, period=14):
    """
    Calculate Average True Range (ATR) for the given price data
    
    Args:
        price_data (pandas.DataFrame): DataFrame containing price data with OHLC columns
        period (int): Period for ATR calculation, default is 14
        
    Returns:
        pandas.Series: Series containing ATR values
    """
    try:
        required_columns = ['High', 'Low', 'Close']
        if price_data.empty or not all(col in price_data.columns for col in required_columns):
            logger.warning("Cannot calculate ATR: price data is empty or missing required columns")
            return pd.Series()
        
        # Calculate true range
        high_low = price_data['High'] - price_data['Low']
        high_close_prev = abs(price_data['High'] - price_data['Close'].shift(1))
        low_close_prev = abs(price_data['Low'] - price_data['Close'].shift(1))
        
        true_range = pd.concat([high_low, high_close_prev, low_close_prev], axis=1).max(axis=1)
        
        # Calculate ATR as exponential moving average of true range
        atr = true_range.ewm(span=period, adjust=False).mean()
        
        return atr
    except Exception as e:
        logger.error(f"Error calculating ATR: {str(e)}")
        return pd.Series()

def preprocess_price_data(price_data):
    """
    Preprocess price data to handle missing values and ensure consistent format
    
    Args:
        price_data (pandas.DataFrame): Raw price data
        
    Returns:
        pandas.DataFrame: Preprocessed price data
    """
    try:
        if price_data.empty:
            logger.warning("Cannot preprocess: price data is empty")
            return price_data
        
        # Create a copy to avoid modifying the original
        df = price_data.copy()
        
        # Ensure all standard columns are present
        expected_columns = ['Open', 'High', 'Low', 'Close', 'Volume']
        
        # Check if all expected columns exist
        missing_columns = [col for col in expected_columns if col not in df.columns]
        if missing_columns:
            logger.warning(f"Missing columns: {missing_columns}, adding with NaN values")
            # Add missing columns with NaN values
            for col in missing_columns:
                df[col] = pd.NA
        
        # Handle missing values in each column
        # For price columns, use forward fill then backward fill
        price_columns = ['Open', 'High', 'Low', 'Close']
        for col in price_columns:
            if col in df.columns:
                df[col] = df[col].fillna(method='ffill').fillna(method='bfill')
        
        # For volume, fill with 0
        if 'Volume' in df.columns:
            df['Volume'] = df['Volume'].fillna(0)
        
        # Ensure index is sorted
        df = df.sort_index()
        
        return df
    except Exception as e:
        logger.error(f"Error preprocessing price data: {str(e)}")
        return price_data
