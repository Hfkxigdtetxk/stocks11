import pandas as pd
import yfinance as yf
from datetime import datetime, timedelta
import time
import os
import json
import logging
import requests
from bs4 import BeautifulSoup

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class GoogleFinanceScraper:
    """
    Scraper for retrieving data from Google Finance via Yahoo Finance API
    (Google Finance doesn't provide a public API, so we use yfinance as an alternative)
    """
    
    def __init__(self):
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
            "Cache-Control": "max-age=0"
        }
    
    def _format_ticker(self, symbol):
        """
        Format ticker symbol for yfinance API
        
        Args:
            symbol (str): Stock symbol/ticker
            
        Returns:
            str: Formatted ticker symbol
        """
        # If the ticker doesn't have an exchange suffix, add the appropriate one
        if "." not in symbol:
            # Check if this is an Indian stock symbol
            if any(char.isalpha() for char in symbol) and len(symbol) <= 10:
                # For NSE stocks, add .NS suffix
                return f"{symbol}.NS"
            # For international symbols, no change needed as yfinance handles them well
        return symbol
    
    def get_price_data(self, symbol, start_date, end_date):
        """
        Retrieves historical price data for a given stock symbol
        
        Args:
            symbol (str): Stock symbol/ticker
            start_date (datetime.date): Start date for data retrieval
            end_date (datetime.date): End date for data retrieval
            
        Returns:
            pandas.DataFrame: DataFrame containing price data
        """
        try:
            logger.info(f"Fetching Google Finance (yfinance) price data for {symbol} from {start_date} to {end_date}")
            
            # Format ticker symbol
            ticker = self._format_ticker(symbol)
            
            # Download data using yfinance
            # Note: yfinance requires end_date + 1 day to include the end_date in results
            df = yf.download(ticker, start=start_date, end=end_date + timedelta(days=1))
            
            if not df.empty:
                # Ensure all standard columns are present
                expected_columns = ['Open', 'High', 'Low', 'Close', 'Volume']
                
                # Check if all expected columns exist
                missing_columns = [col for col in expected_columns if col not in df.columns]
                if missing_columns:
                    logger.warning(f"Missing columns in data: {missing_columns}")
                    # Add missing columns with NaN values
                    for col in missing_columns:
                        df[col] = pd.NA
                
                # Convert index to datetime if it's not already
                if not isinstance(df.index, pd.DatetimeIndex):
                    df.index = pd.to_datetime(df.index)
                
                # Get additional data like market cap if needed
                try:
                    # Get ticker info for additional data
                    ticker_obj = yf.Ticker(ticker)
                    ticker_info = ticker_obj.info
                    
                    # Add market cap as a constant value
                    if 'marketCap' in ticker_info:
                        df['MarketCap'] = ticker_info['marketCap']
                    
                    # Get more detailed info like dividends and stock splits
                    df_actions = ticker_obj.actions
                    if not df_actions.empty:
                        df = df.join(df_actions, how='left')
                except Exception as e:
                    logger.warning(f"Could not get additional ticker info: {str(e)}")
                
                return df
            else:
                logger.warning(f"No data available for {symbol} in the specified date range")
                return pd.DataFrame()
                
        except Exception as e:
            logger.error(f"Error fetching price data for {symbol}: {str(e)}")
            return pd.DataFrame()
    
    def calculate_moving_averages(self, price_data, period, avg_type='SMA'):
        """
        Calculates moving averages from price data
        
        Args:
            price_data (pandas.DataFrame): DataFrame containing price data
            period (int): Period for moving average calculation
            avg_type (str): Type of moving average ('SMA' or 'EMA')
            
        Returns:
            pandas.Series: Series containing moving average values
        """
        if price_data.empty or 'Close' not in price_data.columns:
            return pd.Series()
        
        try:
            if avg_type.upper() == 'SMA':
                return price_data['Close'].rolling(window=period).mean()
            elif avg_type.upper() == 'EMA':
                return price_data['Close'].ewm(span=period, adjust=False).mean()
            else:
                logger.error(f"Unknown average type: {avg_type}")
                return pd.Series()
        except Exception as e:
            logger.error(f"Error calculating {avg_type}: {str(e)}")
            return pd.Series()
    
    def get_fii_dii_data(self, start_date, end_date):
        """
        Retrieves FII/DII data for the specified time period
        
        Args:
            start_date (datetime.date): Start date for data retrieval
            end_date (datetime.date): End date for data retrieval
            
        Returns:
            pandas.DataFrame: DataFrame containing FII/DII data
        """
        try:
            logger.info(f"Fetching FII/DII data from {start_date} to {end_date}")
            
            # Google Finance doesn't provide FII/DII data directly
            # We'll use NSE data as an alternative source
            url = "https://www.nseindia.com/api/fiidiiTradeReact"
            
            all_data = []
            current_date = start_date
            
            while current_date <= end_date:
                date_str = current_date.strftime('%d-%b-%Y')
                
                # Add delay to avoid rate limiting
                time.sleep(1)
                
                params = {
                    "date": date_str
                }
                
                response = requests.get(url, headers=self.headers, params=params)
                
                if response.status_code == 200:
                    data = response.json()
                    
                    if data and isinstance(data, dict) and 'data' in data:
                        for item in data['data']:
                            item['Date'] = current_date
                            all_data.append(item)
                
                # Move to next day
                current_date += timedelta(days=1)
            
            if all_data:
                df = pd.DataFrame(all_data)
                
                # Process and cleanup the DataFrame
                if 'category' in df.columns:
                    # Pivot the data to have FII and DII as separate columns
                    pivot_df = df.pivot(index='Date', columns='category', values=['buyValue', 'sellValue'])
                    
                    # Flatten multi-level columns
                    pivot_df.columns = [f"{col[1]} {col[0]}" for col in pivot_df.columns]
                    
                    # Rename columns to more readable format
                    pivot_df.rename(columns={
                        'FII buyValue': 'FII Buy',
                        'FII sellValue': 'FII Sell',
                        'DII buyValue': 'DII Buy',
                        'DII sellValue': 'DII Sell'
                    }, inplace=True)
                    
                    # Calculate net positions
                    if all(col in pivot_df.columns for col in ['FII Buy', 'FII Sell']):
                        pivot_df['FII Net'] = pivot_df['FII Buy'] - pivot_df['FII Sell']
                    
                    if all(col in pivot_df.columns for col in ['DII Buy', 'DII Sell']):
                        pivot_df['DII Net'] = pivot_df['DII Buy'] - pivot_df['DII Sell']
                    
                    return pivot_df
                
                # If pivoting didn't work, return the original dataframe
                df.set_index('Date', inplace=True)
                return df
            else:
                logger.warning("No FII/DII data found for the specified date range")
                return pd.DataFrame()
            
        except Exception as e:
            logger.error(f"Error fetching FII/DII data: {str(e)}")
            return pd.DataFrame()
    
    def get_block_deals(self, symbol, start_date, end_date):
        """
        Retrieves block deals data for a given stock symbol
        
        Args:
            symbol (str): Stock symbol/ticker
            start_date (datetime.date): Start date for data retrieval
            end_date (datetime.date): End date for data retrieval
            
        Returns:
            pandas.DataFrame: DataFrame containing block deals data
        """
        try:
            logger.info(f"Fetching block deals for {symbol} from {start_date} to {end_date}")
            
            # Google Finance doesn't provide block deals directly
            # Use NSE data as an alternative
            # Format ticker for NSE (remove .NS suffix if present)
            nse_symbol = symbol.replace('.NS', '')
            
            # NSE block deals API endpoint
            url = "https://www.nseindia.com/api/block-deal"
            
            all_deals = []
            current_date = start_date
            
            while current_date <= end_date:
                date_str = current_date.strftime('%d-%m-%Y')
                
                # Add delay to avoid rate limiting
                time.sleep(1)
                
                params = {
                    "index": "CM",
                    "date": date_str
                }
                
                response = requests.get(url, headers=self.headers, params=params)
                
                if response.status_code == 200:
                    data = response.json()
                    
                    if data and 'data' in data and data['data']:
                        for deal in data['data']:
                            # Filter for the requested symbol
                            if deal.get('symbol') == nse_symbol:
                                deal['Date'] = current_date
                                all_deals.append(deal)
                
                # Move to next day
                current_date += timedelta(days=1)
            
            if all_deals:
                df = pd.DataFrame(all_deals)
                
                # Rename columns to standard format
                df.rename(columns={
                    'clientName': 'Client Name',
                    'symbol': 'Symbol',
                    'quantity': 'Quantity',
                    'tradePrice': 'Price',
                    'value': 'Value'
                }, inplace=True)
                
                # Convert date to datetime and set as index
                df['Date'] = pd.to_datetime(df['Date'])
                df.set_index('Date', inplace=True)
                
                # Convert numeric columns
                numeric_columns = ['Quantity', 'Price', 'Value']
                for col in numeric_columns:
                    if col in df.columns:
                        df[col] = pd.to_numeric(df[col], errors='coerce')
                
                return df
            else:
                logger.warning(f"No block deals found for {symbol} in the specified date range")
                return pd.DataFrame()
            
        except Exception as e:
            logger.error(f"Error fetching block deals data for {symbol}: {str(e)}")
            return pd.DataFrame()
    
    def get_bulk_deals(self, symbol, start_date, end_date):
        """
        Retrieves bulk deals data for a given stock symbol
        
        Args:
            symbol (str): Stock symbol/ticker
            start_date (datetime.date): Start date for data retrieval
            end_date (datetime.date): End date for data retrieval
            
        Returns:
            pandas.DataFrame: DataFrame containing bulk deals data
        """
        try:
            logger.info(f"Fetching bulk deals for {symbol} from {start_date} to {end_date}")
            
            # Google Finance doesn't provide bulk deals directly
            # Use NSE data as an alternative
            # Format ticker for NSE (remove .NS suffix if present)
            nse_symbol = symbol.replace('.NS', '')
            
            # NSE bulk deals API endpoint
            url = "https://www.nseindia.com/api/bulk-deal"
            
            all_deals = []
            current_date = start_date
            
            while current_date <= end_date:
                date_str = current_date.strftime('%d-%m-%Y')
                
                # Add delay to avoid rate limiting
                time.sleep(1)
                
                params = {
                    "index": "CM",
                    "date": date_str
                }
                
                response = requests.get(url, headers=self.headers, params=params)
                
                if response.status_code == 200:
                    data = response.json()
                    
                    if data and 'data' in data and data['data']:
                        for deal in data['data']:
                            # Filter for the requested symbol
                            if deal.get('symbol') == nse_symbol:
                                deal['Date'] = current_date
                                all_deals.append(deal)
                
                # Move to next day
                current_date += timedelta(days=1)
            
            if all_deals:
                df = pd.DataFrame(all_deals)
                
                # Rename columns to standard format
                df.rename(columns={
                    'clientName': 'Client Name',
                    'symbol': 'Symbol',
                    'quantity': 'Quantity',
                    'price': 'Price',
                    'value': 'Value',
                    'buySell': 'Transaction Type'
                }, inplace=True)
                
                # Convert date to datetime and set as index
                df['Date'] = pd.to_datetime(df['Date'])
                df.set_index('Date', inplace=True)
                
                # Convert numeric columns
                numeric_columns = ['Quantity', 'Price', 'Value']
                for col in numeric_columns:
                    if col in df.columns:
                        df[col] = pd.to_numeric(df[col], errors='coerce')
                
                return df
            else:
                logger.warning(f"No bulk deals found for {symbol} in the specified date range")
                return pd.DataFrame()
            
        except Exception as e:
            logger.error(f"Error fetching bulk deals data for {symbol}: {str(e)}")
            return pd.DataFrame()
    
    def get_short_selling_data(self, symbol, start_date, end_date):
        """
        Retrieves short selling data for a given stock symbol
        
        Args:
            symbol (str): Stock symbol/ticker
            start_date (datetime.date): Start date for data retrieval
            end_date (datetime.date): End date for data retrieval
            
        Returns:
            pandas.DataFrame: DataFrame containing short selling data
        """
        try:
            logger.info(f"Fetching short selling data for {symbol} from {start_date} to {end_date}")
            
            # Format ticker
            ticker = self._format_ticker(symbol)
            
            # For many markets, short interest data is available bi-weekly or monthly
            # We'll try to get short interest data from Yahoo Finance or similar sources
            
            # Get price data first (needed for volume comparison)
            price_data = self.get_price_data(symbol, start_date, end_date)
            
            if price_data.empty:
                logger.warning(f"No price data available for {symbol}, cannot calculate short selling metrics")
                return pd.DataFrame()
            
            # Try to get short interest data using Yahoo Finance ticker object
            ticker_obj = yf.Ticker(ticker)
            
            # Create a dataframe for short data
            short_data = []
            
            try:
                # Get major holders data which might include short % of float
                holders_data = ticker_obj.major_holders
                if not holders_data.empty:
                    # Extract short interest % from holders data if available
                    short_percent = None
                    for index, row in holders_data.iterrows():
                        if 'Short' in str(row[0]) and '%' in str(row[0]):
                            short_percent = float(row[1].strip('%'))
                            break
                    
                    if short_percent is not None:
                        # Apply this percentage to all dates as an estimate
                        short_date = end_date  # Use the most recent date
                        
                        # Get last available trading volume
                        last_volume = price_data['Volume'].iloc[-1] if 'Volume' in price_data.columns else 0
                        
                        # Calculate estimated short volume
                        short_volume = int(last_volume * (short_percent / 100))
                        
                        # Add to short data
                        short_data.append({
                            'Date': short_date,
                            'Symbol': symbol,
                            'Short Volume': short_volume,
                            'Short Ratio': short_percent / 100
                        })
            except Exception as e:
                logger.warning(f"Could not extract short interest data from major holders: {str(e)}")
            
            # If no data so far, try an alternative method
            if not short_data:
                try:
                    # Try to get short ratio from ticker info
                    ticker_info = ticker_obj.info
                    if 'shortRatio' in ticker_info:
                        short_ratio = ticker_info['shortRatio']
                        short_date = end_date  # Use the most recent date
                        
                        # Get last available trading volume
                        last_volume = price_data['Volume'].iloc[-1] if 'Volume' in price_data.columns else 0
                        
                        # Calculate estimated short volume
                        short_volume = int(last_volume * short_ratio)
                        
                        # Add to short data
                        short_data.append({
                            'Date': short_date,
                            'Symbol': symbol,
                            'Short Volume': short_volume,
                            'Short Ratio': short_ratio
                        })
                except Exception as e:
                    logger.warning(f"Could not extract short ratio from ticker info: {str(e)}")
            
            if short_data:
                df = pd.DataFrame(short_data)
                df.set_index('Date', inplace=True)
                return df
            else:
                logger.warning(f"No short selling data found for {symbol}")
                return pd.DataFrame()
            
        except Exception as e:
            logger.error(f"Error fetching short selling data for {symbol}: {str(e)}")
            return pd.DataFrame()
