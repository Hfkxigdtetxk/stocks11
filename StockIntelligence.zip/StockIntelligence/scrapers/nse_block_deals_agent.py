import os
import requests
import pandas as pd
import logging
from datetime import datetime, timedelta
import json

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class NSEBlockDealsAgent:
    """
    Agent for retrieving block deals data from NSE website via n8n integration
    """
    
    def __init__(self, n8n_webhook_url=None):
        """
        Initialize the NSE Block Deals Agent
        
        Args:
            n8n_webhook_url (str, optional): Webhook URL for the n8n workflow
        """
        self.n8n_webhook_url = n8n_webhook_url
        # Default NSE block deals endpoint (for direct API access if available)
        self.nse_block_deals_endpoint = "https://www.nseindia.com/api/block-deal"
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36",
            "Accept": "application/json, text/plain, */*",
            "Accept-Language": "en-US,en;q=0.5",
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "keep-alive"
        }
        
        # Create data directory if it doesn't exist
        os.makedirs("data", exist_ok=True)
    
    def trigger_n8n_workflow(self, start_date, end_date=None, symbol=None):
        """
        Trigger the n8n workflow to fetch block deals data
        
        Args:
            start_date (datetime.date): Start date for data retrieval
            end_date (datetime.date, optional): End date for data retrieval, defaults to start_date
            symbol (str, optional): Stock symbol to filter block deals
            
        Returns:
            bool: True if workflow triggered successfully, False otherwise
        """
        if not self.n8n_webhook_url:
            logger.error("No n8n webhook URL provided. Cannot trigger workflow.")
            return False
            
        # If end_date not provided, use start_date
        if not end_date:
            end_date = start_date
            
        # Format dates for the request
        start_date_str = start_date.strftime("%d-%m-%Y")
        end_date_str = end_date.strftime("%d-%m-%Y")
        
        # Prepare data for the webhook
        webhook_data = {
            "start_date": start_date_str,
            "end_date": end_date_str
        }
        
        if symbol:
            webhook_data["symbol"] = symbol
        
        try:
            # Trigger the n8n workflow via webhook
            logger.info(f"Triggering n8n workflow for block deals from {start_date_str} to {end_date_str}")
            response = requests.post(self.n8n_webhook_url, json=webhook_data)
            
            if response.status_code == 200:
                logger.info("Successfully triggered n8n workflow")
                return True
            else:
                logger.error(f"Failed to trigger n8n workflow: {response.status_code} - {response.text}")
                return False
                
        except Exception as e:
            logger.error(f"Error triggering n8n workflow: {str(e)}")
            return False
    
    def get_block_deals(self, start_date, end_date=None, symbol=None, use_n8n=True):
        """
        Get block deals data for the specified date range and optional symbol
        Can use either n8n workflow or direct API access
        
        Args:
            start_date (datetime.date): Start date for data retrieval
            end_date (datetime.date, optional): End date for data retrieval, defaults to start_date
            symbol (str, optional): Stock symbol to filter block deals
            use_n8n (bool): Whether to use n8n workflow (True) or direct API (False)
            
        Returns:
            pandas.DataFrame: DataFrame containing block deals data
        """
        try:
            # If end_date not provided, use start_date
            if not end_date:
                end_date = start_date
                
            if use_n8n and self.n8n_webhook_url:
                # Try to trigger n8n workflow
                success = self.trigger_n8n_workflow(start_date, end_date, symbol)
                
                if success:
                    # Check for downloaded file from n8n
                    # Assuming n8n saves file to a predictable location
                    date_part = start_date.strftime("%Y%m%d")
                    if end_date != start_date:
                        date_part += f"_{end_date.strftime('%Y%m%d')}"
                        
                    possible_filenames = [
                        f"data/nse_block_deals_{date_part}.csv",
                        f"data/block_deals_{date_part}.csv",
                        "data/latest_block_deals.csv"
                    ]
                    
                    # Check if any of the possible files exist
                    for filename in possible_filenames:
                        if os.path.exists(filename):
                            logger.info(f"Found block deals CSV file: {filename}")
                            df = pd.read_csv(filename)
                            
                            # Filter by symbol if provided
                            if symbol and 'Symbol' in df.columns:
                                df = df[df['Symbol'] == symbol]
                            
                            # Convert date columns if present
                            date_columns = [col for col in df.columns if 'date' in col.lower()]
                            for col in date_columns:
                                try:
                                    df[col] = pd.to_datetime(df[col])
                                except:
                                    pass
                                    
                            # Set index to date if available
                            if 'Date' in df.columns:
                                df.set_index('Date', inplace=True)
                                
                            return df
                    
                    logger.warning("n8n workflow triggered but no data file found")
                    
                else:
                    logger.warning("Failed to trigger n8n workflow, falling back to direct API")
            
            # Fall back to direct API or alternative method
            logger.info(f"Fetching block deals directly from NSE for {start_date} to {end_date}")
            
            # Here we would implement direct API access to NSE
            # Since NSE API requires authentication and session handling,
            # this is a simplified placeholder
            
            logger.warning("Direct NSE API access not fully implemented. Need to use n8n workflow.")
            
            # Return empty DataFrame if we couldn't get data
            return pd.DataFrame()
                
        except Exception as e:
            logger.error(f"Error getting block deals data: {str(e)}")
            return pd.DataFrame()
    
    def check_n8n_webhook_status(self):
        """
        Check if the n8n webhook is properly configured and accessible
        
        Returns:
            bool: True if webhook is accessible, False otherwise
        """
        if not self.n8n_webhook_url:
            logger.warning("No n8n webhook URL configured")
            return False
            
        try:
            # Try sending a test request to the webhook
            test_data = {"test": True, "timestamp": datetime.now().isoformat()}
            response = requests.post(self.n8n_webhook_url, json=test_data)
            
            if response.status_code == 200:
                logger.info("n8n webhook is accessible")
                return True
            else:
                logger.warning(f"n8n webhook returned status code {response.status_code}")
                return False
                
        except Exception as e:
            logger.error(f"Error checking n8n webhook status: {str(e)}")
            return False
    
    def configure_n8n_webhook(self, webhook_url):
        """
        Configure the n8n webhook URL
        
        Args:
            webhook_url (str): The n8n webhook URL
            
        Returns:
            bool: True if configured successfully
        """
        self.n8n_webhook_url = webhook_url
        logger.info(f"Configured n8n webhook URL: {webhook_url}")
        return True
