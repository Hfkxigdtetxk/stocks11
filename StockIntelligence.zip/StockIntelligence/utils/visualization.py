import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class StockVisualizer:
    """
    Utility class for visualizing stock market data
    Provides functions for creating interactive charts and plots
    """
    
    def __init__(self, theme='light'):
        """
        Initialize the Stock Visualizer
        
        Args:
            theme (str): Chart theme, 'light' or 'dark', default is 'light'
        """
        self.theme = theme
        
        # Set default colors based on theme
        if theme == 'dark':
            self.background_color = '#1e1e1e'
            self.text_color = 'white'
            self.grid_color = '#333333'
            self.color_palette = ['#00bcd4', '#ff9800', '#4caf50', '#f44336', '#9c27b0', '#ffeb3b']
        else:  # light theme
            self.background_color = 'white'
            self.text_color = 'black'
            self.grid_color = '#e0e0e0'
            self.color_palette = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b']
    
    def plot_price_chart(self, price_data, title=None, time_period=None, include_volume=True):
        """
        Create an interactive price chart with optional volume
        
        Args:
            price_data (pandas.DataFrame): DataFrame with OHLC and Volume data
            title (str, optional): Chart title
            time_period (str, optional): Time period label for the chart
            include_volume (bool): Whether to include volume bars, default is True
            
        Returns:
            plotly.graph_objects.Figure: Plotly figure object
        """
        try:
            if price_data.empty or 'Close' not in price_data.columns:
                logger.warning("Cannot create price chart: price data is empty or missing required columns")
                return None
            
            # Prepare layout with or without volume subplot
            if include_volume and 'Volume' in price_data.columns:
                fig = make_subplots(rows=2, cols=1, shared_xaxes=True, 
                                   vertical_spacing=0.05,
                                   row_heights=[0.7, 0.3])
            else:
                fig = go.Figure()
            
            # Set title
            if title:
                chart_title = title
                if time_period:
                    chart_title += f" ({time_period})"
            elif time_period:
                chart_title = time_period
            else:
                chart_title = "Stock Price Chart"
            
            # Check available columns and create appropriate chart
            if all(col in price_data.columns for col in ['Open', 'High', 'Low', 'Close']):
                # Create OHLC or Candlestick chart
                candle = go.Candlestick(
                    x=price_data.index,
                    open=price_data['Open'],
                    high=price_data['High'],
                    low=price_data['Low'],
                    close=price_data['Close'],
                    name="Price",
                    increasing_line_color=self.color_palette[2],  # Green for up
                    decreasing_line_color=self.color_palette[3]   # Red for down
                )
                
                if include_volume and 'Volume' in price_data.columns:
                    fig.add_trace(candle, row=1, col=1)
                else:
                    fig.add_trace(candle)
            else:
                # Create line chart for Close price
                line = go.Scatter(
                    x=price_data.index,
                    y=price_data['Close'],
                    mode='lines',
                    name="Close Price",
                    line=dict(color=self.color_palette[0])
                )
                
                if include_volume and 'Volume' in price_data.columns:
                    fig.add_trace(line, row=1, col=1)
                else:
                    fig.add_trace(line)
            
            # Add volume bars if requested
            if include_volume and 'Volume' in price_data.columns:
                # Create volume bars
                volume = go.Bar(
                    x=price_data.index,
                    y=price_data['Volume'],
                    name="Volume",
                    marker=dict(color=self.color_palette[1])
                )
                
                fig.add_trace(volume, row=2, col=1)
                
                # Update y-axis labels for volume
                fig.update_yaxes(title_text="Volume", row=2, col=1)
            
            # Update layout
            fig.update_layout(
                title=chart_title,
                xaxis_title="Date",
                yaxis_title="Price",
                plot_bgcolor=self.background_color,
                paper_bgcolor=self.background_color,
                font=dict(color=self.text_color),
                xaxis_rangeslider_visible=False,
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="center", x=0.5),
                height=600
            )
            
            # Update grid lines
            fig.update_xaxes(showgrid=True, gridwidth=1, gridcolor=self.grid_color)
            fig.update_yaxes(showgrid=True, gridwidth=1, gridcolor=self.grid_color)
            
            return fig
            
        except Exception as e:
            logger.error(f"Error creating price chart: {str(e)}")
            return None
    
    def plot_moving_averages(self, price_data, ma_dict, title=None):
        """
        Create a chart with price and multiple moving averages
        
        Args:
            price_data (pandas.DataFrame): DataFrame with at least Close price data
            ma_dict (dict): Dictionary of {ma_name: ma_series} pairs
            title (str, optional): Chart title
            
        Returns:
            plotly.graph_objects.Figure: Plotly figure object
        """
        try:
            if price_data.empty or 'Close' not in price_data.columns:
                logger.warning("Cannot create moving averages chart: price data is empty or missing 'Close' column")
                return None
            
            if not ma_dict:
                logger.warning("No moving averages provided for chart")
                return None
            
            # Create figure
            fig = go.Figure()
            
            # Add price line
            fig.add_trace(go.Scatter(
                x=price_data.index,
                y=price_data['Close'],
                mode='lines',
                name="Close Price",
                line=dict(color=self.color_palette[0], width=2)
            ))
            
            # Add each moving average
            for i, (ma_name, ma_series) in enumerate(ma_dict.items()):
                if ma_series.empty:
                    continue
                    
                color_idx = (i + 1) % len(self.color_palette)
                fig.add_trace(go.Scatter(
                    x=ma_series.index,
                    y=ma_series,
                    mode='lines',
                    name=ma_name,
                    line=dict(color=self.color_palette[color_idx], width=1.5)
                ))
            
            # Set title
            chart_title = title if title else "Price with Moving Averages"
            
            # Update layout
            fig.update_layout(
                title=chart_title,
                xaxis_title="Date",
                yaxis_title="Price",
                plot_bgcolor=self.background_color,
                paper_bgcolor=self.background_color,
                font=dict(color=self.text_color),
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="center", x=0.5),
                height=500
            )
            
            # Update grid lines
            fig.update_xaxes(showgrid=True, gridwidth=1, gridcolor=self.grid_color)
            fig.update_yaxes(showgrid=True, gridwidth=1, gridcolor=self.grid_color)
            
            return fig
            
        except Exception as e:
            logger.error(f"Error creating moving averages chart: {str(e)}")
            return None
    
    def plot_rsi(self, price_data, rsi_series, overbought=70, oversold=30, title=None):
        """
        Create an RSI chart with overbought/oversold levels
        
        Args:
            price_data (pandas.DataFrame): DataFrame with Close price data
            rsi_series (pandas.Series): Series containing RSI values
            overbought (float): Overbought level, default is 70
            oversold (float): Oversold level, default is 30
            title (str, optional): Chart title
            
        Returns:
            plotly.graph_objects.Figure: Plotly figure object
        """
        try:
            if rsi_series.empty:
                logger.warning("Cannot create RSI chart: RSI data is empty")
                return None
            
            # Create subplots: price chart and RSI
            fig = make_subplots(rows=2, cols=1, shared_xaxes=True, 
                               vertical_spacing=0.05,
                               row_heights=[0.7, 0.3])
            
            # Add price line to top subplot
            if not price_data.empty and 'Close' in price_data.columns:
                fig.add_trace(go.Scatter(
                    x=price_data.index,
                    y=price_data['Close'],
                    mode='lines',
                    name="Close Price",
                    line=dict(color=self.color_palette[0], width=2)
                ), row=1, col=1)
            
            # Add RSI line to bottom subplot
            fig.add_trace(go.Scatter(
                x=rsi_series.index,
                y=rsi_series,
                mode='lines',
                name="RSI",
                line=dict(color=self.color_palette[1], width=1.5)
            ), row=2, col=1)
            
            # Add overbought level line
            fig.add_trace(go.Scatter(
                x=[rsi_series.index[0], rsi_series.index[-1]],
                y=[overbought, overbought],
                mode='lines',
                name=f"Overbought ({overbought})",
                line=dict(color=self.color_palette[3], width=1, dash='dash')
            ), row=2, col=1)
            
            # Add oversold level line
            fig.add_trace(go.Scatter(
                x=[rsi_series.index[0], rsi_series.index[-1]],
                y=[oversold, oversold],
                mode='lines',
                name=f"Oversold ({oversold})",
                line=dict(color=self.color_palette[2], width=1, dash='dash')
            ), row=2, col=1)
            
            # Add centerline
            fig.add_trace(go.Scatter(
                x=[rsi_series.index[0], rsi_series.index[-1]],
                y=[50, 50],
                mode='lines',
                name="Centerline (50)",
                line=dict(color=self.text_color, width=0.5, dash='dot')
            ), row=2, col=1)
            
            # Set title
            chart_title = title if title else "RSI Indicator"
            
            # Update layout
            fig.update_layout(
                title=chart_title,
                xaxis_title="Date",
                plot_bgcolor=self.background_color,
                paper_bgcolor=self.background_color,
                font=dict(color=self.text_color),
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="center", x=0.5),
                height=600
            )
            
            # Update y-axis labels and range
            fig.update_yaxes(title_text="Price", row=1, col=1)
            fig.update_yaxes(title_text="RSI", range=[0, 100], row=2, col=1)
            
            # Update grid lines
            fig.update_xaxes(showgrid=True, gridwidth=1, gridcolor=self.grid_color)
            fig.update_yaxes(showgrid=True, gridwidth=1, gridcolor=self.grid_color)
            
            return fig
            
        except Exception as e:
            logger.error(f"Error creating RSI chart: {str(e)}")
            return None
    
    def plot_macd(self, price_data, macd, signal, histogram, title=None):
        """
        Create a MACD chart with signal line and histogram
        
        Args:
            price_data (pandas.DataFrame): DataFrame with Close price data
            macd (pandas.Series): MACD line series
            signal (pandas.Series): Signal line series
            histogram (pandas.Series): Histogram series
            title (str, optional): Chart title
            
        Returns:
            plotly.graph_objects.Figure: Plotly figure object
        """
        try:
            if macd.empty or signal.empty or histogram.empty:
                logger.warning("Cannot create MACD chart: MACD data is empty")
                return None
            
            # Create subplots: price chart and MACD
            fig = make_subplots(rows=2, cols=1, shared_xaxes=True, 
                               vertical_spacing=0.05,
                               row_heights=[0.7, 0.3])
            
            # Add price line to top subplot
            if not price_data.empty and 'Close' in price_data.columns:
                fig.add_trace(go.Scatter(
                    x=price_data.index,
                    y=price_data['Close'],
                    mode='lines',
                    name="Close Price",
                    line=dict(color=self.color_palette[0], width=2)
                ), row=1, col=1)
            
            # Add MACD line to bottom subplot
            fig.add_trace(go.Scatter(
                x=macd.index,
                y=macd,
                mode='lines',
                name="MACD",
                line=dict(color=self.color_palette[1], width=1.5)
            ), row=2, col=1)
            
            # Add Signal line
            fig.add_trace(go.Scatter(
                x=signal.index,
                y=signal,
                mode='lines',
                name="Signal",
                line=dict(color=self.color_palette[4], width=1.5)
            ), row=2, col=1)
            
            # Add Histogram as bar chart
            colors = [self.color_palette[2] if val >= 0 else self.color_palette[3] for val in histogram]
            fig.add_trace(go.Bar(
                x=histogram.index,
                y=histogram,
                name="Histogram",
                marker=dict(color=colors)
            ), row=2, col=1)
            
            # Add zero line
            fig.add_trace(go.Scatter(
                x=[histogram.index[0], histogram.index[-1]],
                y=[0, 0],
                mode='lines',
                name="Zero Line",
                line=dict(color=self.text_color, width=0.5, dash='dot')
            ), row=2, col=1)
            
            # Set title
            chart_title = title if title else "MACD Indicator"
            
            # Update layout
            fig.update_layout(
                title=chart_title,
                xaxis_title="Date",
                plot_bgcolor=self.background_color,
                paper_bgcolor=self.background_color,
                font=dict(color=self.text_color),
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="center", x=0.5),
                height=600
            )
            
            # Update y-axis labels
            fig.update_yaxes(title_text="Price", row=1, col=1)
            fig.update_yaxes(title_text="MACD", row=2, col=1)
            
            # Update grid lines
            fig.update_xaxes(showgrid=True, gridwidth=1, gridcolor=self.grid_color)
            fig.update_yaxes(showgrid=True, gridwidth=1, gridcolor=self.grid_color)
            
            return fig
            
        except Exception as e:
            logger.error(f"Error creating MACD chart: {str(e)}")
            return None
    
    def plot_bollinger_bands(self, price_data, upper_band, middle_band, lower_band, title=None):
        """
        Create a chart with price and Bollinger Bands
        
        Args:
            price_data (pandas.DataFrame): DataFrame with Close price data
            upper_band (pandas.Series): Upper Bollinger Band series
            middle_band (pandas.Series): Middle Bollinger Band series
            lower_band (pandas.Series): Lower Bollinger Band series
            title (str, optional): Chart title
            
        Returns:
            plotly.graph_objects.Figure: Plotly figure object
        """
        try:
            if upper_band.empty or middle_band.empty or lower_band.empty:
                logger.warning("Cannot create Bollinger Bands chart: Bollinger Bands data is empty")
                return None
            
            # Create figure
            fig = go.Figure()
            
            # Add price line
            if not price_data.empty and 'Close' in price_data.columns:
                fig.add_trace(go.Scatter(
                    x=price_data.index,
                    y=price_data['Close'],
                    mode='lines',
                    name="Close Price",
                    line=dict(color=self.color_palette[0], width=2)
                ))
            
            # Add Bollinger Bands
            fig.add_trace(go.Scatter(
                x=upper_band.index,
                y=upper_band,
                mode='lines',
                name="Upper Band",
                line=dict(color=self.color_palette[1], width=1.5)
            ))
            
            fig.add_trace(go.Scatter(
                x=middle_band.index,
                y=middle_band,
                mode='lines',
                name="Middle Band (SMA)",
                line=dict(color=self.color_palette[4], width=1.5, dash='dash')
            ))
            
            fig.add_trace(go.Scatter(
                x=lower_band.index,
                y=lower_band,
                mode='lines',
                name="Lower Band",
                line=dict(color=self.color_palette[1], width=1.5)
            ))
            
            # Add filled area between bands
            fig.add_trace(go.Scatter(
                x=upper_band.index.tolist() + lower_band.index.tolist()[::-1],
                y=upper_band.tolist() + lower_band.tolist()[::-1],
                fill='toself',
                fillcolor=f"rgba({','.join(str(int(c[1:3], 16)) for c in [self.color_palette[1][:7]])},0.2)",
                line=dict(color='rgba(255,255,255,0)'),
                name="Band Range"
            ))
            
            # Set title
            chart_title = title if title else "Bollinger Bands"
            
            # Update layout
            fig.update_layout(
                title=chart_title,
                xaxis_title="Date",
                yaxis_title="Price",
                plot_bgcolor=self.background_color,
                paper_bgcolor=self.background_color,
                font=dict(color=self.text_color),
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="center", x=0.5),
                height=500
            )
            
            # Update grid lines
            fig.update_xaxes(showgrid=True, gridwidth=1, gridcolor=self.grid_color)
            fig.update_yaxes(showgrid=True, gridwidth=1, gridcolor=self.grid_color)
            
            return fig
            
        except Exception as e:
            logger.error(f"Error creating Bollinger Bands chart: {str(e)}")
            return None
    
    def plot_volume_profile(self, volume_profile, horizontal=True, title=None):
        """
        Create a volume profile chart
        
        Args:
            volume_profile (pandas.DataFrame): DataFrame with Price and Volume columns
            horizontal (bool): Whether to display bars horizontally, default is True
            title (str, optional): Chart title
            
        Returns:
            plotly.graph_objects.Figure: Plotly figure object
        """
        try:
            if volume_profile.empty or 'Price' not in volume_profile.columns or 'Volume' not in volume_profile.columns:
                logger.warning("Cannot create volume profile chart: volume profile data is empty or missing required columns")
                return None
            
            # Create figure
            fig = go.Figure()
            
            # Add volume profile bars
            if horizontal:
                # Horizontal bars (price on y-axis, volume on x-axis)
                fig.add_trace(go.Bar(
                    x=volume_profile['Volume'],
                    y=volume_profile['Price'],
                    orientation='h',
                    name="Volume Profile",
                    marker=dict(color=self.color_palette[1])
                ))
                
                # Update axes labels
                fig.update_layout(
                    xaxis_title="Volume",
                    yaxis_title="Price"
                )
            else:
                # Vertical bars (price on x-axis, volume on y-axis)
                fig.add_trace(go.Bar(
                    x=volume_profile['Price'],
                    y=volume_profile['Volume'],
                    name="Volume Profile",
                    marker=dict(color=self.color_palette[1])
                ))
                
                # Update axes labels
                fig.update_layout(
                    xaxis_title="Price",
                    yaxis_title="Volume"
                )
            
            # Set title
            chart_title = title if title else "Volume Profile"
            
            # Update layout
            fig.update_layout(
                title=chart_title,
                plot_bgcolor=self.background_color,
                paper_bgcolor=self.background_color,
                font=dict(color=self.text_color),
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="center", x=0.5),
                height=500
            )
            
            # Update grid lines
            fig.update_xaxes(showgrid=True, gridwidth=1, gridcolor=self.grid_color)
            fig.update_yaxes(showgrid=True, gridwidth=1, gridcolor=self.grid_color)
            
            return fig
            
        except Exception as e:
            logger.error(f"Error creating volume profile chart: {str(e)}")
            return None
    
    def plot_volume_indicators(self, price_data, volume_indicators, title=None):
        """
        Create a chart with price and volume indicators
        
        Args:
            price_data (pandas.DataFrame): DataFrame with OHLC and Volume data
            volume_indicators (dict): Dictionary of {indicator_name: indicator_series} pairs
            title (str, optional): Chart title
            
        Returns:
            plotly.graph_objects.Figure: Plotly figure object
        """
        try:
            if price_data.empty or 'Close' not in price_data.columns or 'Volume' not in price_data.columns:
                logger.warning("Cannot create volume indicators chart: price data is empty or missing required columns")
                return None
            
            if not volume_indicators:
                logger.warning("No volume indicators provided for chart")
                return None
            
            # Create subplots: price chart, volume chart, and indicators
            fig = make_subplots(rows=3, cols=1, shared_xaxes=True, 
                               vertical_spacing=0.05,
                               row_heights=[0.5, 0.25, 0.25])
            
            # Add price candlestick to top subplot
            if all(col in price_data.columns for col in ['Open', 'High', 'Low', 'Close']):
                # Create OHLC or Candlestick chart
                candle = go.Candlestick(
                    x=price_data.index,
                    open=price_data['Open'],
                    high=price_data['High'],
                    low=price_data['Low'],
                    close=price_data['Close'],
                    name="Price",
                    increasing_line_color=self.color_palette[2],  # Green for up
                    decreasing_line_color=self.color_palette[3]   # Red for down
                )
                
                fig.add_trace(candle, row=1, col=1)
            else:
                # Create line chart for Close price
                line = go.Scatter(
                    x=price_data.index,
                    y=price_data['Close'],
                    mode='lines',
                    name="Close Price",
                    line=dict(color=self.color_palette[0])
                )
                
                fig.add_trace(line, row=1, col=1)
            
            # Add volume bars to middle subplot
            volume = go.Bar(
                x=price_data.index,
                y=price_data['Volume'],
                name="Volume",
                marker=dict(color=self.color_palette[1])
            )
            
            fig.add_trace(volume, row=2, col=1)
            
            # Add each volume indicator to bottom subplot
            for i, (indicator_name, indicator_data) in enumerate(volume_indicators.items()):
                if indicator_data.empty:
                    continue
                
                color_idx = (i + 2) % len(self.color_palette)
                fig.add_trace(go.Scatter(
                    x=indicator_data.index,
                    y=indicator_data,
                    mode='lines',
                    name=indicator_name,
                    line=dict(color=self.color_palette[color_idx], width=1.5)
                ), row=3, col=1)
            
            # Set title
            chart_title = title if title else "Volume Analysis"
            
            # Update layout
            fig.update_layout(
                title=chart_title,
                xaxis_title="Date",
                plot_bgcolor=self.background_color,
                paper_bgcolor=self.background_color,
                font=dict(color=self.text_color),
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="center", x=0.5),
                height=800,
                xaxis_rangeslider_visible=False
            )
            
            # Update y-axis labels
            fig.update_yaxes(title_text="Price", row=1, col=1)
            fig.update_yaxes(title_text="Volume", row=2, col=1)
            fig.update_yaxes(title_text="Indicators", row=3, col=1)
            
            # Update grid lines
            fig.update_xaxes(showgrid=True, gridwidth=1, gridcolor=self.grid_color)
            fig.update_yaxes(showgrid=True, gridwidth=1, gridcolor=self.grid_color)
            
            return fig
            
        except Exception as e:
            logger.error(f"Error creating volume indicators chart: {str(e)}")
            return None
    
    def plot_comparison_chart(self, symbol_data_dict, title=None, normalize=True):
        """
        Create a comparison chart for multiple symbols
        
        Args:
            symbol_data_dict (dict): Dictionary of {symbol_name: price_data_df} pairs
            title (str, optional): Chart title
            normalize (bool): Whether to normalize prices for better comparison, default is True
            
        Returns:
            plotly.graph_objects.Figure: Plotly figure object
        """
        try:
            if not symbol_data_dict:
                logger.warning("No symbol data provided for comparison chart")
                return None
            
            # Filter out empty DataFrames
            symbol_data_dict = {k: v for k, v in symbol_data_dict.items() if not v.empty and 'Close' in v.columns}
            
            if not symbol_data_dict:
                logger.warning("All symbol data is empty or missing 'Close' column")
                return None
            
            # Create figure
            fig = go.Figure()
            
            # Add each symbol's price line
            for i, (symbol_name, price_data) in enumerate(symbol_data_dict.items()):
                # Get close prices
                close_prices = price_data['Close']
                
                # Normalize if requested
                if normalize:
                    # Scale prices to start at 100
                    first_price = close_prices.iloc[0]
                    if first_price > 0:  # Avoid division by zero
                        close_prices = (close_prices / first_price) * 100
                
                color_idx = i % len(self.color_palette)
                fig.add_trace(go.Scatter(
                    x=price_data.index,
                    y=close_prices,
                    mode='lines',
                    name=symbol_name,
                    line=dict(color=self.color_palette[color_idx], width=1.5)
                ))
            
            # Set title
            chart_title = title if title else "Symbol Comparison"
            
            # Set y-axis title based on normalization
            if normalize:
                y_axis_title = "Normalized Price (Starting at 100)"
            else:
                y_axis_title = "Price"
            
            # Update layout
            fig.update_layout(
                title=chart_title,
                xaxis_title="Date",
                yaxis_title=y_axis_title,
                plot_bgcolor=self.background_color,
                paper_bgcolor=self.background_color,
                font=dict(color=self.text_color),
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="center", x=0.5),
                height=500
            )
            
            # Update grid lines
            fig.update_xaxes(showgrid=True, gridwidth=1, gridcolor=self.grid_color)
            fig.update_yaxes(showgrid=True, gridwidth=1, gridcolor=self.grid_color)
            
            return fig
            
        except Exception as e:
            logger.error(f"Error creating comparison chart: {str(e)}")
            return None
    
    def plot_fii_dii_data(self, fii_dii_data, title=None):
        """
        Create a chart for FII/DII data
        
        Args:
            fii_dii_data (pandas.DataFrame): DataFrame with FII and DII buy/sell data
            title (str, optional): Chart title
            
        Returns:
            plotly.graph_objects.Figure: Plotly figure object
        """
        try:
            if fii_dii_data.empty:
                logger.warning("Cannot create FII/DII chart: data is empty")
                return None
            
            # Check for required columns
            required_columns = [
                col for col in [
                    'FII Buy', 'FII Sell', 'DII Buy', 'DII Sell',
                    'FII Net', 'DII Net'
                ] if col in fii_dii_data.columns
            ]
            
            if len(required_columns) < 2:
                logger.warning("FII/DII data is missing required columns")
                return None
            
            # Create figure
            fig = go.Figure()
            
            # Add FII/DII data as grouped bar chart or line chart
            if all(col in fii_dii_data.columns for col in ['FII Net', 'DII Net']):
                # Net values available, show as lines
                fig.add_trace(go.Scatter(
                    x=fii_dii_data.index,
                    y=fii_dii_data['FII Net'],
                    mode='lines+markers',
                    name="FII Net",
                    line=dict(color=self.color_palette[0], width=2)
                ))
                
                fig.add_trace(go.Scatter(
                    x=fii_dii_data.index,
                    y=fii_dii_data['DII Net'],
                    mode='lines+markers',
                    name="DII Net",
                    line=dict(color=self.color_palette[1], width=2)
                ))
                
                # Add zero line
                fig.add_trace(go.Scatter(
                    x=[fii_dii_data.index[0], fii_dii_data.index[-1]],
                    y=[0, 0],
                    mode='lines',
                    name="Zero Line",
                    line=dict(color=self.text_color, width=0.5, dash='dot')
                ))
            else:
                # Show buy/sell as grouped bars
                for i, col in enumerate(required_columns):
                    color_idx = i % len(self.color_palette)
                    fig.add_trace(go.Bar(
                        x=fii_dii_data.index,
                        y=fii_dii_data[col],
                        name=col,
                        marker=dict(color=self.color_palette[color_idx])
                    ))
            
            # Set title
            chart_title = title if title else "FII/DII Activity"
            
            # Update layout
            fig.update_layout(
                title=chart_title,
                xaxis_title="Date",
                yaxis_title="Value (₹ Crore)",
                plot_bgcolor=self.background_color,
                paper_bgcolor=self.background_color,
                font=dict(color=self.text_color),
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="center", x=0.5),
                height=500,
                barmode='group'
            )
            
            # Update grid lines
            fig.update_xaxes(showgrid=True, gridwidth=1, gridcolor=self.grid_color)
            fig.update_yaxes(showgrid=True, gridwidth=1, gridcolor=self.grid_color)
            
            return fig
            
        except Exception as e:
            logger.error(f"Error creating FII/DII chart: {str(e)}")
            return None
    
    def create_summary_dashboard(self, price_data, indicators_dict, title=None):
        """
        Create a comprehensive dashboard with multiple indicators
        
        Args:
            price_data (pandas.DataFrame): DataFrame with OHLC and Volume data
            indicators_dict (dict): Dictionary of {indicator_name: indicator_data} pairs
            title (str, optional): Dashboard title
            
        Returns:
            plotly.graph_objects.Figure: Plotly figure object
        """
        try:
            if price_data.empty or 'Close' not in price_data.columns:
                logger.warning("Cannot create dashboard: price data is empty or missing required columns")
                return None
            
            # Figure out how many subplot rows we need
            num_rows = 2  # At minimum, we have price and volume
            
            # Check if we have specific indicators that get their own rows
            has_rsi = 'RSI' in indicators_dict and not indicators_dict['RSI'].empty
            has_macd = all(k in indicators_dict and not indicators_dict[k].empty for k in ['MACD', 'Signal', 'Histogram'])
            
            if has_rsi:
                num_rows += 1
            
            if has_macd:
                num_rows += 1
            
            # Create subplots with appropriate heights
            row_heights = [0.5, 0.2]  # Price and volume
            if has_rsi:
                row_heights.append(0.15)
            if has_macd:
                row_heights.append(0.15)
            
            fig = make_subplots(rows=num_rows, cols=1, shared_xaxes=True, 
                                vertical_spacing=0.05,
                                row_heights=row_heights)
            
            # Add price candlestick to top subplot
            if all(col in price_data.columns for col in ['Open', 'High', 'Low', 'Close']):
                # Create Candlestick chart
                candle = go.Candlestick(
                    x=price_data.index,
                    open=price_data['Open'],
                    high=price_data['High'],
                    low=price_data['Low'],
                    close=price_data['Close'],
                    name="Price",
                    increasing_line_color=self.color_palette[2],  # Green for up
                    decreasing_line_color=self.color_palette[3]   # Red for down
                )
                
                fig.add_trace(candle, row=1, col=1)
            else:
                # Create line chart for Close price
                line = go.Scatter(
                    x=price_data.index,
                    y=price_data['Close'],
                    mode='lines',
                    name="Close Price",
                    line=dict(color=self.color_palette[0])
                )
                
                fig.add_trace(line, row=1, col=1)
            
            # Add moving averages to price chart if available
            ma_types = ['SMA_20', 'SMA_50', 'SMA_200', 'EMA_20', 'EMA_50']
            for ma_type in ma_types:
                if ma_type in indicators_dict and not indicators_dict[ma_type].empty:
                    color_idx = (ma_types.index(ma_type) + 1) % len(self.color_palette)
                    fig.add_trace(go.Scatter(
                        x=indicators_dict[ma_type].index,
                        y=indicators_dict[ma_type],
                        mode='lines',
                        name=ma_type,
                        line=dict(color=self.color_palette[color_idx], width=1)
                    ), row=1, col=1)
            
            # Add Bollinger Bands if available
            if all(k in indicators_dict and not indicators_dict[k].empty for k in ['Upper Band', 'Middle Band', 'Lower Band']):
                # Upper Band
                fig.add_trace(go.Scatter(
                    x=indicators_dict['Upper Band'].index,
                    y=indicators_dict['Upper Band'],
                    mode='lines',
                    name="Upper Band",
                    line=dict(color='rgba(250,128,114,0.7)', width=1, dash='dash')
                ), row=1, col=1)
                
                # Middle Band already added as SMA
                
                # Lower Band
                fig.add_trace(go.Scatter(
                    x=indicators_dict['Lower Band'].index,
                    y=indicators_dict['Lower Band'],
                    mode='lines',
                    name="Lower Band",
                    line=dict(color='rgba(250,128,114,0.7)', width=1, dash='dash')
                ), row=1, col=1)
                
                # Filled area between bands
                fig.add_trace(go.Scatter(
                    x=indicators_dict['Upper Band'].index.tolist() + indicators_dict['Lower Band'].index.tolist()[::-1],
                    y=indicators_dict['Upper Band'].tolist() + indicators_dict['Lower Band'].tolist()[::-1],
                    fill='toself',
                    fillcolor='rgba(250,128,114,0.1)',
                    line=dict(color='rgba(255,255,255,0)'),
                    name="Band Range",
                    showlegend=False
                ), row=1, col=1)
            
            # Add volume bars to second subplot
            if 'Volume' in price_data.columns:
                volume = go.Bar(
                    x=price_data.index,
                    y=price_data['Volume'],
                    name="Volume",
                    marker=dict(color=self.color_palette[1])
                )
                
                fig.add_trace(volume, row=2, col=1)
                
                # Add volume MA if available
                if 'Volume MA' in indicators_dict and not indicators_dict['Volume MA'].empty:
                    fig.add_trace(go.Scatter(
                        x=indicators_dict['Volume MA'].index,
                        y=indicators_dict['Volume MA'],
                        mode='lines',
                        name="Volume MA",
                        line=dict(color=self.color_palette[4], width=1.5)
                    ), row=2, col=1)
            
            # Current row index for additional indicators
            current_row = 3
            
            # Add RSI to its own subplot if available
            if has_rsi:
                fig.add_trace(go.Scatter(
                    x=indicators_dict['RSI'].index,
                    y=indicators_dict['RSI'],
                    mode='lines',
                    name="RSI",
                    line=dict(color=self.color_palette[5], width=1.5)
                ), row=current_row, col=1)
                
                # Add overbought/oversold levels
                fig.add_trace(go.Scatter(
                    x=[indicators_dict['RSI'].index[0], indicators_dict['RSI'].index[-1]],
                    y=[70, 70],
                    mode='lines',
                    name="Overbought (70)",
                    line=dict(color=self.color_palette[3], width=1, dash='dash')
                ), row=current_row, col=1)
                
                fig.add_trace(go.Scatter(
                    x=[indicators_dict['RSI'].index[0], indicators_dict['RSI'].index[-1]],
                    y=[30, 30],
                    mode='lines',
                    name="Oversold (30)",
                    line=dict(color=self.color_palette[2], width=1, dash='dash')
                ), row=current_row, col=1)
                
                # Add centerline
                fig.add_trace(go.Scatter(
                    x=[indicators_dict['RSI'].index[0], indicators_dict['RSI'].index[-1]],
                    y=[50, 50],
                    mode='lines',
                    name="Centerline (50)",
                    line=dict(color=self.text_color, width=0.5, dash='dot')
                ), row=current_row, col=1)
                
                # Update y-axis range for RSI
                fig.update_yaxes(title_text="RSI", range=[0, 100], row=current_row, col=1)
                
                current_row += 1
            
            # Add MACD to its own subplot if available
            if has_macd:
                # MACD line
                fig.add_trace(go.Scatter(
                    x=indicators_dict['MACD'].index,
                    y=indicators_dict['MACD'],
                    mode='lines',
                    name="MACD",
                    line=dict(color=self.color_palette[1], width=1.5)
                ), row=current_row, col=1)
                
                # Signal line
                fig.add_trace(go.Scatter(
                    x=indicators_dict['Signal'].index,
                    y=indicators_dict['Signal'],
                    mode='lines',
                    name="Signal",
                    line=dict(color=self.color_palette[4], width=1.5)
                ), row=current_row, col=1)
                
                # Histogram
                histogram = indicators_dict['Histogram']
                colors = [self.color_palette[2] if val >= 0 else self.color_palette[3] for val in histogram]
                fig.add_trace(go.Bar(
                    x=histogram.index,
                    y=histogram,
                    name="Histogram",
                    marker=dict(color=colors)
                ), row=current_row, col=1)
                
                # Add zero line
                fig.add_trace(go.Scatter(
                    x=[histogram.index[0], histogram.index[-1]],
                    y=[0, 0],
                    mode='lines',
                    name="Zero Line",
                    line=dict(color=self.text_color, width=0.5, dash='dot')
                ), row=current_row, col=1)
                
                # Update y-axis label for MACD
                fig.update_yaxes(title_text="MACD", row=current_row, col=1)
            
            # Set title
            chart_title = title if title else "Technical Analysis Dashboard"
            
            # Update layout
            fig.update_layout(
                title=chart_title,
                xaxis_title="Date",
                plot_bgcolor=self.background_color,
                paper_bgcolor=self.background_color,
                font=dict(color=self.text_color),
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="center", x=0.5),
                height=1000,
                xaxis_rangeslider_visible=False
            )
            
            # Update y-axis labels
            fig.update_yaxes(title_text="Price", row=1, col=1)
            fig.update_yaxes(title_text="Volume", row=2, col=1)
            
            # Update grid lines
            fig.update_xaxes(showgrid=True, gridwidth=1, gridcolor=self.grid_color)
            fig.update_yaxes(showgrid=True, gridwidth=1, gridcolor=self.grid_color)
            
            return fig
            
        except Exception as e:
            logger.error(f"Error creating summary dashboard: {str(e)}")
            return None