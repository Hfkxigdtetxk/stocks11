import streamlit as st
import pandas as pd
import os
import datetime
from datetime import timedelta
import matplotlib.pyplot as plt
import plotly.express as px
import plotly.graph_objects as go

# Import custom modules
from scrapers.nseindia_scraper import NSEIndiaScraper
from scrapers.bseindia_scraper import BSEIndiaScraper
from scrapers.google_finance_scraper import GoogleFinanceScraper
from scrapers.yahoo_finance_scraper import YahooFinanceScraper
from scrapers.investing_com_scraper import InvestingComScraper
from scrapers.alpha_vantage_scraper import AlphaVantageScraper
from scrapers.tradingview_scraper import TradingViewScraper
from scrapers.screener_scraper import ScreenerScraper
from scrapers.nse_block_deals_agent import NSEBlockDealsAgent
from utils.data_processor import (
    calculate_sma, calculate_ema, calculate_rsi, calculate_macd, calculate_bollinger_bands,
    calculate_volume_ma, calculate_obv, calculate_vwap, calculate_volume_profile, calculate_money_flow_index
)
from utils.visualization import StockVisualizer
from utils.excel_manager import ExcelManager

# Set page configuration
st.set_page_config(
    page_title="Stock Market Data Scraper",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded"
)

# App title and description
st.title("📊 Stock Market Data Scraper")
st.markdown("""
This application allows you to scrape historical stock market data from multiple sources:
NSE, BSE, Google Finance, Yahoo Finance, Investing.com, Alpha Vantage, TradingView, and Screener.in.

You can retrieve various types of data including:
- Price Data with OHLC (Open, High, Low, Close) values and Volume
- Technical Indicators: SMA, EMA, RSI, MACD, Bollinger Bands
- Volume Analysis: Volume MA, OBV (On-Balance Volume), VWAP, MFI
- Market Data: FII/DII activity, Block Deals, Bulk Deals, Short Selling
- Fundamental Data: Company financials, quarterly results, peer comparison

All data can be visualized and exported to CSV or Excel formats.

**Note**: Some data sources like Alpha Vantage may require an API key for full functionality.
""")

# Add prominent download button at the very top if data is available
if 'scraping_complete' in st.session_state and st.session_state.scraping_complete and 'scraped_data' in st.session_state and st.session_state.scraped_data:
    # Check if we have any non-empty data frames
    has_valid_data = False
    for key, df in st.session_state.scraped_data.items():
        if not df.empty:
            has_valid_data = True
            break
    
    if has_valid_data:
        # Display a clear download section at the top
        with st.container():
            st.info("🔵 SCRAPED DATA IS READY FOR DOWNLOAD")
            
            col1, col2 = st.columns(2)
            
            # Get the stock symbol from session state
            stock_symbol = ""
            for key in st.session_state.keys():
                if key.endswith("_stock_symbol"):
                    stock_symbol = st.session_state[key]
                    break
            
            if not stock_symbol:
                stock_symbol = "stock"
            
            # Excel download
            with col1:
                # Find Excel file in data directory
                if os.path.exists("data"):
                    excel_files = [f for f in os.listdir("data") if f.endswith(".xlsx") and stock_symbol in f]
                    
                    if excel_files:
                        newest_file = sorted(excel_files, key=lambda x: os.path.getmtime(os.path.join("data", x)), reverse=True)[0]
                        file_path = os.path.join("data", newest_file)
                        
                        if os.path.exists(file_path):
                            try:
                                with open(file_path, "rb") as f:
                                    excel_data = f.read()
                                    st.download_button(
                                        label="⬇️ DOWNLOAD COMPLETE DATASET (Excel)",
                                        data=excel_data,
                                        file_name=f"{stock_symbol}_market_data.xlsx",
                                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                        key="top_excel_button",
                                        use_container_width=True
                                    )
                            except Exception as e:
                                st.warning(f"Could not prepare Excel download: {str(e)}")
            
            # CSV download for price data
            with col2:
                if "Price Data" in st.session_state.scraped_data and not st.session_state.scraped_data["Price Data"].empty:
                    try:
                        price_data_csv = st.session_state.scraped_data["Price Data"].to_csv(index=True)
                        st.download_button(
                            label="⬇️ DOWNLOAD PRICE DATA (CSV)",
                            data=price_data_csv,
                            file_name=f"{stock_symbol}_price_data.csv",
                            mime="text/csv",
                            key="top_csv_button",
                            use_container_width=True
                        )
                    except Exception as e:
                        st.warning(f"Could not prepare CSV download: {str(e)}")
            
            st.markdown("---")

# Initialize session state variables if they don't exist
if 'scraping_complete' not in st.session_state:
    st.session_state.scraping_complete = False
if 'scraped_data' not in st.session_state:
    st.session_state.scraped_data = None
if 'data_source' not in st.session_state:
    st.session_state.data_source = None
if 'error_message' not in st.session_state:
    st.session_state.error_message = None
if 'n8n_webhook_url' not in st.session_state:
    st.session_state.n8n_webhook_url = None
if 'block_deals_files' not in st.session_state:
    st.session_state.block_deals_files = []

# Sidebar for data source and stock selection
st.sidebar.header("Data Configuration")

# Select data source
data_source = st.sidebar.selectbox(
    "Select Data Source",
    ["NSE (National Stock Exchange)", "BSE (Bombay Stock Exchange)", "Google Finance", 
     "Yahoo Finance", "Investing.com", "Alpha Vantage", "TradingView", "Screener.in",
     "NSE Block Deals Agent (n8n)"]
)

# Stock symbol input
stock_symbol = st.sidebar.text_input("Enter Stock Symbol/Ticker", "RELIANCE" if data_source.startswith("NSE") or data_source.startswith("BSE") else "RELIANCE.NS")

# Data type selection
data_types = st.sidebar.multiselect(
    "Select Data Types to Retrieve",
    ["Price Data", 
     # Technical Indicators
     "SMA (Simple Moving Average)", "EMA (Exponential Moving Average)", 
     "RSI (Relative Strength Index)", "MACD", "Bollinger Bands", 
     "Volume Analysis", 
     # Market Data
     "FII/DII Data", "Block Deals", "Bulk Deals", "Short Selling Data",
     # Fundamental Data
     "Company Overview", "Financial Statements", "Quarterly Results", "Peer Comparison"],
    default=["Price Data"]
)

# Time period selection
time_period_options = {
    "1 Week": 7,
    "1 Month": 30,
    "3 Months": 90,
    "6 Months": 180,
    "1 Year": 365,
    "2 Years": 730,
    "5 Years": 1825
}

time_period = st.sidebar.selectbox(
    "Select Time Period",
    list(time_period_options.keys()),
    index=4  # Default to 1 Year
)

# Calculate date range
end_date = datetime.date.today()
start_date = end_date - timedelta(days=time_period_options[time_period])

# Custom date range option
use_custom_date = st.sidebar.checkbox("Use Custom Date Range")
if use_custom_date:
    col1, col2 = st.sidebar.columns(2)
    with col1:
        start_date = st.date_input("Start Date", start_date)
    with col2:
        end_date = st.date_input("End Date", end_date)

# Technical indicator parameters
sma_period = None
ema_period = None
rsi_period = None
macd_fast_period = None
macd_slow_period = None
macd_signal_period = None
bb_period = None
bb_std = None
volume_ma_period = None

# Only show relevant parameter inputs based on selected data types
if "SMA (Simple Moving Average)" in data_types:
    sma_period = st.sidebar.slider("SMA Period (days)", 5, 200, 50)

if "EMA (Exponential Moving Average)" in data_types:
    ema_period = st.sidebar.slider("EMA Period (days)", 5, 200, 20)
    
if "RSI (Relative Strength Index)" in data_types:
    rsi_period = st.sidebar.slider("RSI Period", 7, 30, 14)
    
if "MACD" in data_types:
    macd_fast_period = st.sidebar.slider("MACD Fast Period", 5, 30, 12)
    macd_slow_period = st.sidebar.slider("MACD Slow Period", 10, 50, 26)
    macd_signal_period = st.sidebar.slider("MACD Signal Period", 5, 20, 9)
    
if "Bollinger Bands" in data_types:
    bb_period = st.sidebar.slider("Bollinger Bands Period", 5, 50, 20)
    bb_std = st.sidebar.slider("Bollinger Bands Standard Deviation", 1, 4, 2)
    
if "Volume Analysis" in data_types:
    volume_ma_period = st.sidebar.slider("Volume MA Period", 5, 50, 20)

# Function to initialize the appropriate scraper based on user selection
def get_scraper(source):
    if "NSE Block Deals Agent" in source:
        # Check if we have an n8n webhook URL environment variable
        n8n_webhook_url = os.environ.get("N8N_WEBHOOK_URL")
        if not n8n_webhook_url:
            st.warning("No n8n webhook URL configured. Block deals data retrieval may not work correctly.")
            st.info("Please enter your n8n webhook URL in the configuration section below.")
            # Allow user to enter webhook URL directly if not in environment variables
            webhook_url = st.text_input("Enter n8n Webhook URL for Block Deals Agent", "")
            if webhook_url:
                n8n_webhook_url = webhook_url
        
        return NSEBlockDealsAgent(n8n_webhook_url=n8n_webhook_url)
    elif "NSE" in source and "Block Deals Agent" not in source:
        return NSEIndiaScraper()
    elif "BSE" in source:
        return BSEIndiaScraper()
    elif "Google" in source:
        return GoogleFinanceScraper()
    elif "Yahoo" in source:
        return YahooFinanceScraper()
    elif "Investing" in source:
        return InvestingComScraper()
    elif "Alpha Vantage" in source:
        # Check if we have an API key in environment variables
        api_key = os.environ.get("ALPHA_VANTAGE_API_KEY")
        if not api_key:
            st.warning("No Alpha Vantage API key found. Some features may not work correctly.")
            st.info("You can get a free API key from https://www.alphavantage.co/support/#api-key")
        return AlphaVantageScraper(api_key=api_key)
    elif "TradingView" in source:
        return TradingViewScraper()
    elif "Screener" in source:
        return ScreenerScraper()
    else:
        # Default to Yahoo Finance as fallback
        return YahooFinanceScraper()

# Button to start scraping
if st.sidebar.button("Fetch Data"):
    st.session_state.scraping_complete = False
    st.session_state.error_message = None
    
    try:
        with st.spinner(f"Fetching data from {data_source} for {stock_symbol}..."):
            # Get the appropriate scraper
            scraper = get_scraper(data_source)
            
            # Initialize dictionary to store all data
            all_data = {}
            
            # Fetch price data (always needed for SMA/EMA calculations)
            if "Price Data" in data_types or "SMA (Simple Moving Average)" in data_types or "EMA (Exponential Moving Average)" in data_types:
                price_data = scraper.get_price_data(stock_symbol, start_date, end_date)
                if price_data is not None and not price_data.empty:
                    all_data["Price Data"] = price_data
                    
                    # Calculate SMA if requested
                    if "SMA (Simple Moving Average)" in data_types and sma_period is not None:
                        sma_data = calculate_sma(price_data, sma_period)
                        all_data["SMA"] = sma_data
                    
                    # Calculate EMA if requested
                    if "EMA (Exponential Moving Average)" in data_types and ema_period is not None:
                        ema_data = calculate_ema(price_data, ema_period)
                        all_data["EMA"] = ema_data
            
            # Fetch FII/DII data if requested
            if "FII/DII Data" in data_types:
                fii_dii_data = scraper.get_fii_dii_data(start_date, end_date)
                if fii_dii_data is not None and not fii_dii_data.empty:
                    all_data["FII/DII Data"] = fii_dii_data
            
            # Fetch block deals if requested
            if "Block Deals" in data_types:
                block_deals = scraper.get_block_deals(stock_symbol, start_date, end_date)
                if block_deals is not None and not block_deals.empty:
                    all_data["Block Deals"] = block_deals
            
            # Fetch bulk deals if requested
            if "Bulk Deals" in data_types:
                bulk_deals = scraper.get_bulk_deals(stock_symbol, start_date, end_date)
                if bulk_deals is not None and not bulk_deals.empty:
                    all_data["Bulk Deals"] = bulk_deals
            
            # Fetch short selling data if requested
            if "Short Selling Data" in data_types:
                short_selling = scraper.get_short_selling_data(stock_symbol, start_date, end_date)
                if short_selling is not None and not short_selling.empty:
                    all_data["Short Selling Data"] = short_selling
            
            # Calculate RSI if requested
            if "RSI (Relative Strength Index)" in data_types and "Price Data" in all_data and rsi_period is not None:
                price_data = all_data["Price Data"]
                rsi_data = calculate_rsi(price_data, period=rsi_period)
                all_data["RSI"] = rsi_data
            
            # Calculate MACD if requested
            if "MACD" in data_types and "Price Data" in all_data and macd_fast_period is not None and macd_slow_period is not None and macd_signal_period is not None:
                price_data = all_data["Price Data"]
                macd, signal, histogram = calculate_macd(price_data, 
                                                       fast_period=macd_fast_period, 
                                                       slow_period=macd_slow_period, 
                                                       signal_period=macd_signal_period)
                all_data["MACD"] = macd
                all_data["Signal"] = signal
                all_data["Histogram"] = histogram
            
            # Calculate Bollinger Bands if requested
            if "Bollinger Bands" in data_types and "Price Data" in all_data and bb_period is not None and bb_std is not None:
                price_data = all_data["Price Data"]
                upper_band, middle_band, lower_band = calculate_bollinger_bands(price_data, 
                                                                              period=bb_period, 
                                                                              num_std=bb_std)
                all_data["Upper Band"] = upper_band
                all_data["Middle Band"] = middle_band
                all_data["Lower Band"] = lower_band
            
            # Calculate Volume indicators if requested
            if "Volume Analysis" in data_types and "Price Data" in all_data and volume_ma_period is not None:
                price_data = all_data["Price Data"]
                # Volume Moving Average
                volume_ma = calculate_volume_ma(price_data, period=volume_ma_period)
                all_data["Volume MA"] = volume_ma
                
                # On-Balance Volume
                obv = calculate_obv(price_data)
                all_data["OBV"] = obv
                
                # Volume-Weighted Average Price
                vwap = calculate_vwap(price_data)
                all_data["VWAP"] = vwap
                
                # Money Flow Index
                mfi = calculate_money_flow_index(price_data)
                all_data["MFI"] = mfi
                
            # Fetch fundamental data if using Alpha Vantage or Screener
            if data_source in ["Alpha Vantage", "Screener.in"]:
                # Company Overview
                if "Company Overview" in data_types:
                    if data_source == "Alpha Vantage":
                        overview_data = scraper.get_fundamental_data(stock_symbol, data_type="overview")
                        if overview_data is not None and not overview_data.empty:
                            all_data["Company Overview"] = overview_data
                    elif data_source == "Screener.in":
                        overview_data = scraper.get_company_info(stock_symbol)
                        if overview_data is not None and not overview_data.empty:
                            all_data["Company Overview"] = overview_data
                
                # Financial Statements
                if "Financial Statements" in data_types:
                    if data_source == "Alpha Vantage":
                        income_data = scraper.get_fundamental_data(stock_symbol, data_type="income")
                        if income_data is not None and not income_data.empty:
                            all_data["Income Statement"] = income_data
                            
                        balance_data = scraper.get_fundamental_data(stock_symbol, data_type="balance")
                        if balance_data is not None and not balance_data.empty:
                            all_data["Balance Sheet"] = balance_data
                            
                        cash_flow_data = scraper.get_fundamental_data(stock_symbol, data_type="cash")
                        if cash_flow_data is not None and not cash_flow_data.empty:
                            all_data["Cash Flow"] = cash_flow_data
                    elif data_source == "Screener.in":
                        financial_data = scraper.get_fundamental_data(stock_symbol)
                        if financial_data is not None and not financial_data.empty:
                            all_data["Financial Statements"] = financial_data
                
                # Quarterly Results
                if "Quarterly Results" in data_types:
                    if data_source == "Alpha Vantage":
                        earnings_data = scraper.get_fundamental_data(stock_symbol, data_type="earnings")
                        if earnings_data is not None and not earnings_data.empty:
                            all_data["Quarterly Results"] = earnings_data
                    elif data_source == "Screener.in":
                        quarterly_data = scraper.get_quarterly_results(stock_symbol)
                        if quarterly_data is not None and not quarterly_data.empty:
                            all_data["Quarterly Results"] = quarterly_data
                
                # Peer Comparison
                if "Peer Comparison" in data_types and data_source == "Screener.in":
                    peer_data = scraper.get_peer_comparison(stock_symbol)
                    if peer_data is not None and not peer_data.empty:
                        all_data["Peer Comparison"] = peer_data
                        
            # Get technical analysis from TradingView
            if data_source == "TradingView":
                if "Company Overview" in data_types:
                    tech_analysis = scraper.get_technical_analysis(stock_symbol)
                    if tech_analysis is not None and not tech_analysis.empty:
                        all_data["Technical Analysis"] = tech_analysis
                        
                if "Financial Statements" in data_types:
                    ideas = scraper.get_ideas(stock_symbol)
                    if ideas is not None and not ideas.empty:
                        all_data["Trading Ideas"] = ideas
            
            # Save to session state
            st.session_state.scraped_data = all_data
            st.session_state.data_source = data_source
            st.session_state.scraping_complete = True
            
            # Create data directory if it doesn't exist
            os.makedirs("data", exist_ok=True)
            
            # Check if we have any valid data first
            has_valid_data = False
            for key, df in all_data.items():
                if not df.empty:
                    has_valid_data = True
                    break
            
            if has_valid_data:
                # Initialize Excel Manager and save data
                excel_manager = ExcelManager(output_dir="data")
                file_name = f"{stock_symbol}_{start_date.strftime('%Y%m%d')}_{end_date.strftime('%Y%m%d')}.xlsx"
                export_path = excel_manager.export_multiple_sheets(all_data, file_name)
                
                if export_path and os.path.exists(export_path):
                    # Add success message
                    st.sidebar.success("Data scraped successfully!")
                    
                    # Add a big download button
                    st.sidebar.markdown("### Download Scraped Data")
                    
                    try:
                        with open(export_path, "rb") as f:
                            excel_data = f.read()
                            st.sidebar.download_button(
                                label="⬇️ DOWNLOAD DATA",
                                data=excel_data,
                                file_name=f"{stock_symbol}_scraped_data.xlsx",
                                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                key="sidebar_download_button"
                            )
                            
                            # Also add a CSV option for simplicity
                            if "Price Data" in all_data and not all_data["Price Data"].empty:
                                csv_data = all_data["Price Data"].to_csv(index=True)
                                st.sidebar.download_button(
                                    label="Download as CSV",
                                    data=csv_data,
                                    file_name=f"{stock_symbol}_price_data.csv",
                                    mime="text/csv",
                                    key="sidebar_csv_button"
                                )
                    except Exception as e:
                        st.sidebar.warning(f"Error preparing download: {str(e)}")
                else:
                    st.sidebar.warning("Could not create data file for download.")
            else:
                st.sidebar.warning("No valid data was retrieved for download.")
                st.sidebar.info("Try a different data source or stock symbol.")
                
                # Set scraping complete to False since we didn't get valid data
                st.session_state.scraping_complete = False
            
    except Exception as e:
        st.session_state.error_message = str(e)
        st.error(f"Error fetching data: {e}")

# Special section for NSE Block Deals Agent
if "NSE Block Deals Agent" in data_source:
    st.header("NSE Block Deals Agent")
    st.markdown("""
    This agent uses an n8n workflow to fetch block deals data directly from the NSE website.
    It will automatically navigate to the NSE website, search for block deals, and download the CSV files.
    
    ℹ️ **Note**: You need to provide a valid n8n webhook URL that triggers a workflow configured to scrape the NSE website.
    """)
    
    # n8n integration configuration
    with st.expander("n8n Integration Configuration", expanded=True):
        webhook_url = st.text_input(
            "n8n Webhook URL", 
            value=st.session_state.n8n_webhook_url if st.session_state.n8n_webhook_url else "",
            help="Enter the URL of your n8n webhook that triggers the NSE block deals scraping workflow"
        )
        
        if webhook_url:
            st.session_state.n8n_webhook_url = webhook_url
            
        st.markdown("""        
        ### How to set up the n8n workflow:
        
        1. Create a new workflow in n8n
        2. Add a Webhook node as the trigger
        3. Configure nodes to navigate to the NSE website and search for block deals
        4. Add nodes to download the CSV file and save it
        5. Use the webhook URL from step 2 above
        """)
        
        # Test connection button
        if st.button("Test n8n Connection"):
            if not webhook_url:
                st.warning("Please enter a webhook URL first")
            else:
                with st.spinner("Testing connection to n8n webhook..."):
                    try:
                        # Initialize agent with the webhook URL
                        agent = NSEBlockDealsAgent(n8n_webhook_url=webhook_url)
                        status = agent.check_n8n_webhook_status()
                        
                        if status:
                            st.success("✅ Successfully connected to n8n webhook!")
                        else:
                            st.error("❌ Failed to connect to n8n webhook. Please check the URL and make sure your n8n instance is running.")
                    except Exception as e:
                        st.error(f"❌ Error testing n8n connection: {str(e)}")

    # Block deals fetching form
    with st.form("block_deals_form"):
        st.subheader("Fetch Block Deals Data")
        
        col1, col2 = st.columns(2)
        
        with col1:
            block_deals_date = st.date_input("Date", value=datetime.date.today())
            
        with col2:
            symbol_filter = st.text_input("Symbol Filter (optional)", value="")
        
        fetch_button = st.form_submit_button("Fetch Block Deals")
        
        if fetch_button:
            if not st.session_state.n8n_webhook_url:
                st.warning("Please configure the n8n webhook URL first")
            else:
                with st.spinner("Fetching block deals data from NSE website via n8n..."):
                    try:
                        # Initialize agent with the webhook URL
                        agent = NSEBlockDealsAgent(n8n_webhook_url=st.session_state.n8n_webhook_url)
                        
                        # Trigger the n8n workflow
                        if symbol_filter:
                            block_deals = agent.get_block_deals(block_deals_date, symbol=symbol_filter)
                        else:
                            block_deals = agent.get_block_deals(block_deals_date)
                        
                        if block_deals is not None and not block_deals.empty:
                            st.success("✅ Successfully fetched block deals data!")
                            
                            # Save to session state
                            if "scraped_data" not in st.session_state:
                                st.session_state.scraped_data = {}
                            
                            st.session_state.scraped_data["Block Deals"] = block_deals
                            st.session_state.scraping_complete = True
                            
                            # Display the data
                            st.subheader("Block Deals Data")
                            st.dataframe(block_deals)
                            
                            # Create Excel file
                            excel_manager = ExcelManager(output_dir="data")
                            file_name = f"NSE_Block_Deals_{block_deals_date.strftime('%Y%m%d')}.xlsx"
                            export_path = excel_manager.export_to_excel(block_deals, file_name)
                            
                            # Create download button
                            if export_path and os.path.exists(export_path):
                                try:
                                    with open(export_path, "rb") as f:
                                        excel_data = f.read()
                                        st.download_button(
                                            label="⬇️ Download Block Deals Data (Excel)",
                                            data=excel_data,
                                            file_name=file_name,
                                            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                                        )
                                except Exception as e:
                                    st.warning(f"Could not prepare Excel download: {str(e)}")
                        else:
                            st.warning("No block deals data found for the selected date or symbol")
                    except Exception as e:
                        st.error(f"Error fetching block deals data: {str(e)}")
                        
    # Check for existing block deals CSV files
    st.subheader("Previously Downloaded Block Deals Files")
    if os.path.exists("data"):
        block_deals_files = [f for f in os.listdir("data") if "block_deals" in f.lower() or "nse_block" in f.lower() or "blockdeals" in f.lower()]
        
        if block_deals_files:
            st.session_state.block_deals_files = block_deals_files
            
            file_select = st.selectbox("Select a file to view", options=block_deals_files)
            
            if file_select:
                file_path = os.path.join("data", file_select)
                try:
                    df = pd.read_csv(file_path)
                    st.dataframe(df)
                    
                    # Add download button for the selected file
                    with open(file_path, "rb") as f:
                        file_data = f.read()
                        st.download_button(
                            label="⬇️ Download Selected File",
                            data=file_data,
                            file_name=file_select,
                            mime="text/csv" if file_select.endswith(".csv") else "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                        )
                except Exception as e:
                    st.warning(f"Could not read file {file_select}: {str(e)}")
        else:
            st.info("No block deals files found. Use the form above to fetch block deals data.")
    else:
        st.info("No data directory found. Use the form above to fetch block deals data.")

# Display error message if any
if st.session_state.error_message:
    st.error(f"Error: {st.session_state.error_message}")

# Display data and visualizations if scraping is complete
if st.session_state.scraping_complete and st.session_state.scraped_data:
    # Check if we have any valid data
    has_valid_data = False
    for key, df in st.session_state.scraped_data.items():
        if not df.empty:
            has_valid_data = True
            break
            
    # Add a simple, clear EXPORT button before anything else
    if has_valid_data:
        # Create a dedicated standalone export section with a visible border
        st.markdown("""
        <div style="padding: 15px; border: 2px solid #4CAF50; border-radius: 10px; margin-bottom: 20px;">
        <h2 style="text-align: center; color: #4CAF50;">EXPORT DATA</h2>
        </div>
        """, unsafe_allow_html=True)
        
        # Create the export file
        file_name = f"{stock_symbol}_{start_date.strftime('%Y%m%d')}_{end_date.strftime('%Y%m%d')}.xlsx"
        export_path = f"data/{file_name}"
        
        if os.path.exists(export_path):
            with open(export_path, "rb") as f:
                excel_data = f.read()
                
                # Center the button
                col1, col2, col3 = st.columns([1, 2, 1])
                with col2:
                    # Big, clear, centered export button
                    st.download_button(
                        label="EXPORT SCRAPED DATA",
                        data=excel_data,
                        file_name=f"{stock_symbol}_data.xlsx",
                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        key="main_export_button",
                        use_container_width=True
                    )
                    
        # Add spacing after the export button
        st.markdown("<br>", unsafe_allow_html=True)
        # Add large standalone download button at the top of the page
        st.markdown("## 📊 Stock Market Data Ready")
        st.markdown("")
        
        # Create a row of action buttons
        col1, col2, col3 = st.columns([1, 1, 1])
        
        # Get the path to the Excel file
        file_name = f"{stock_symbol}_{start_date.strftime('%Y%m%d')}_{end_date.strftime('%Y%m%d')}.xlsx"
        export_path = f"data/{file_name}"
        
        # Add download button if file exists
        if os.path.exists(export_path):
            try:
                with open(export_path, "rb") as f:
                    excel_data = f.read()
                    download_filename = f"{stock_symbol}_market_data.xlsx"
                    
                    with col1:
                        st.download_button(
                            label="⬇️ DOWNLOAD DATA",
                            data=excel_data,
                            file_name=download_filename,
                            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            key="main_download_button",
                            use_container_width=True,
                        )
            except Exception as e:
                with col1:
                    st.warning(f"Could not prepare Excel file: {str(e)}")
        
        # CSV download for price data
        if "Price Data" in st.session_state.scraped_data and not st.session_state.scraped_data["Price Data"].empty:
            try:
                price_data_csv = st.session_state.scraped_data["Price Data"].to_csv(index=True)
                with col2:
                    st.download_button(
                        label="📄 DOWNLOAD CSV",
                        data=price_data_csv,
                        file_name=f"{stock_symbol}_price_data.csv",
                        mime="text/csv",
                        key="main_csv_button",
                        use_container_width=True,
                    )
            except Exception as e:
                with col2:
                    st.warning(f"Could not prepare CSV file: {str(e)}")
        
        with col3:
            st.markdown(
                "<div style='text-align: center; padding: 0.5em 0;'>"
                "<h3 style='margin: 0; color: #4CAF50;'>✅ Data Ready!</h3>"
                "</div>",
                unsafe_allow_html=True
            )
        
        st.markdown("---")
    else:
        st.warning("No valid data was retrieved from the selected source.")
        st.info("Please try a different data source (like Yahoo Finance) or stock symbol (like 'AAPL' or 'MSFT').")
        
        # Reset the scraping_complete state since we don't have valid data
        st.session_state.scraping_complete = False
    # Create tabs for different data types
    tabs = st.tabs(["Data View", "Visualizations", "Export"])
    
    with tabs[0]:  # Data View tab
        st.header("Retrieved Data")
        
        # Display each type of data in expandable sections
        for data_type, data in st.session_state.scraped_data.items():
            with st.expander(f"{data_type} Data", expanded=(data_type == "Price Data")):
                st.dataframe(data, use_container_width=True)
    
    with tabs[1]:  # Visualizations tab
        st.header("Data Visualizations")
        
        # Initialize visualizer
        visualizer = StockVisualizer(theme='light')
        
        # Price data visualization (candlestick chart)
        if "Price Data" in st.session_state.scraped_data:
            st.subheader("Price Chart")
            price_data = st.session_state.scraped_data["Price Data"]
            
            # Create price chart with volume
            try:
                fig = visualizer.plot_price_chart(
                    price_data=price_data,
                    title=f"{stock_symbol} - {data_source}",
                    time_period=f"{start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}",
                    include_volume=True
                )
                if fig is not None:
                    st.plotly_chart(fig, use_container_width=True)
                else:
                    st.warning("Could not generate price chart due to incomplete data.")
            except Exception as e:
                st.warning(f"Could not generate price chart: {str(e)}")
                st.info("This may happen with non-standard data formats or when using certain data sources like TradingView or Screener.in that don't provide direct price data.")
            
            # Moving Averages chart if available
            if "SMA" in st.session_state.scraped_data or "EMA" in st.session_state.scraped_data:
                st.subheader("Moving Averages")
                ma_dict = {}
                if "SMA" in st.session_state.scraped_data:
                    ma_dict[f"SMA ({sma_period})"] = st.session_state.scraped_data["SMA"]
                if "EMA" in st.session_state.scraped_data:
                    ma_dict[f"EMA ({ema_period})"] = st.session_state.scraped_data["EMA"]
                
                try:
                    ma_fig = visualizer.plot_moving_averages(
                        price_data=price_data,
                        ma_dict=ma_dict,
                        title=f"{stock_symbol} - Moving Averages"
                    )
                    if ma_fig is not None:
                        st.plotly_chart(ma_fig, use_container_width=True)
                    else:
                        st.warning("Could not generate moving averages chart due to incomplete data.")
                except Exception as e:
                    st.warning(f"Could not generate moving averages chart: {str(e)}")
            
            # RSI visualization if available
            if "RSI" in st.session_state.scraped_data:
                st.subheader("Relative Strength Index (RSI)")
                rsi_data = st.session_state.scraped_data["RSI"]
                try:
                    rsi_fig = visualizer.plot_rsi(
                        price_data=price_data,
                        rsi_series=rsi_data,
                        title=f"{stock_symbol} - RSI ({rsi_period})"
                    )
                    if rsi_fig is not None:
                        st.plotly_chart(rsi_fig, use_container_width=True)
                    else:
                        st.warning("Could not generate RSI chart due to incomplete data.")
                except Exception as e:
                    st.warning(f"Could not generate RSI chart: {str(e)}")
            
            # MACD visualization if available
            if all(k in st.session_state.scraped_data for k in ["MACD", "Signal", "Histogram"]):
                st.subheader("Moving Average Convergence Divergence (MACD)")
                macd = st.session_state.scraped_data["MACD"]
                signal = st.session_state.scraped_data["Signal"]
                histogram = st.session_state.scraped_data["Histogram"]
                
                try:
                    macd_fig = visualizer.plot_macd(
                        price_data=price_data,
                        macd=macd,
                        signal=signal,
                        histogram=histogram,
                        title=f"{stock_symbol} - MACD ({macd_fast_period}/{macd_slow_period}/{macd_signal_period})"
                    )
                    if macd_fig is not None:
                        st.plotly_chart(macd_fig, use_container_width=True)
                    else:
                        st.warning("Could not generate MACD chart due to incomplete data.")
                except Exception as e:
                    st.warning(f"Could not generate MACD chart: {str(e)}")
            
            # Bollinger Bands visualization if available
            if all(k in st.session_state.scraped_data for k in ["Upper Band", "Middle Band", "Lower Band"]):
                st.subheader("Bollinger Bands")
                upper_band = st.session_state.scraped_data["Upper Band"]
                middle_band = st.session_state.scraped_data["Middle Band"]
                lower_band = st.session_state.scraped_data["Lower Band"]
                
                try:
                    bb_fig = visualizer.plot_bollinger_bands(
                        price_data=price_data,
                        upper_band=upper_band,
                        middle_band=middle_band,
                        lower_band=lower_band,
                        title=f"{stock_symbol} - Bollinger Bands ({bb_period}, {bb_std}σ)"
                    )
                    if bb_fig is not None:
                        st.plotly_chart(bb_fig, use_container_width=True)
                    else:
                        st.warning("Could not generate Bollinger Bands chart due to incomplete data.")
                except Exception as e:
                    st.warning(f"Could not generate Bollinger Bands chart: {str(e)}")
            
            # Volume Analysis visualization if available
            volume_indicators = {}
            if "Volume MA" in st.session_state.scraped_data:
                volume_indicators["Volume MA"] = st.session_state.scraped_data["Volume MA"]
            if "OBV" in st.session_state.scraped_data:
                volume_indicators["OBV"] = st.session_state.scraped_data["OBV"]
            if "VWAP" in st.session_state.scraped_data:
                volume_indicators["VWAP"] = st.session_state.scraped_data["VWAP"]
            if "MFI" in st.session_state.scraped_data:
                volume_indicators["MFI"] = st.session_state.scraped_data["MFI"]
            
            if volume_indicators:
                st.subheader("Volume Analysis")
                try:
                    volume_fig = visualizer.plot_volume_indicators(
                        price_data=price_data,
                        volume_indicators=volume_indicators,
                        title=f"{stock_symbol} - Volume Analysis"
                    )
                    if volume_fig is not None:
                        st.plotly_chart(volume_fig, use_container_width=True)
                    else:
                        st.warning("Could not generate Volume Analysis chart due to incomplete data.")
                except Exception as e:
                    st.warning(f"Could not generate Volume Analysis chart: {str(e)}")
        
        # FII/DII Data visualization
        if "FII/DII Data" in st.session_state.scraped_data:
            st.subheader("FII/DII Data")
            fii_dii_data = st.session_state.scraped_data["FII/DII Data"]
            
            # Create FII/DII visualization using our visualizer
            if not fii_dii_data.empty:
                # Calculate FII-DII Net positions if needed
                if all(col in fii_dii_data.columns for col in ['FII Buy', 'FII Sell', 'DII Buy', 'DII Sell']):
                    if 'FII Net' not in fii_dii_data.columns:
                        fii_dii_data['FII Net'] = fii_dii_data['FII Buy'] - fii_dii_data['FII Sell']
                    if 'DII Net' not in fii_dii_data.columns:
                        fii_dii_data['DII Net'] = fii_dii_data['DII Buy'] - fii_dii_data['DII Sell']
                
                try:
                    fii_dii_fig = visualizer.plot_fii_dii_data(
                        fii_dii_data=fii_dii_data,
                        title="FII/DII Trading Activity"
                    )
                    if fii_dii_fig is not None:
                        st.plotly_chart(fii_dii_fig, use_container_width=True)
                    else:
                        st.warning("Could not generate FII/DII chart due to incomplete data.")
                except Exception as e:
                    st.warning(f"Could not generate FII/DII chart: {str(e)}")
        
        # Block Deals visualization
        if "Block Deals" in st.session_state.scraped_data:
            st.subheader("Block Deals")
            block_deals = st.session_state.scraped_data["Block Deals"]
            
            if not block_deals.empty and 'Quantity' in block_deals.columns and 'Price' in block_deals.columns:
                try:
                    fig = px.scatter(
                        block_deals,
                        x=block_deals.index if block_deals.index.name == 'Date' else block_deals['Date'],
                        y='Price',
                        size='Quantity',
                        color='Client Name' if 'Client Name' in block_deals.columns else None,
                        hover_data=['Quantity', 'Price'],
                        title="Block Deals - Size represents quantity"
                    )
                    st.plotly_chart(fig, use_container_width=True)
                except Exception as e:
                    st.warning(f"Could not generate Block Deals visualization: {str(e)}")
        
        # Short Selling visualization
        if "Short Selling Data" in st.session_state.scraped_data:
            st.subheader("Short Selling Activity")
            short_data = st.session_state.scraped_data["Short Selling Data"]
            
            if not short_data.empty and 'Short Volume' in short_data.columns:
                try:
                    fig = px.bar(
                        short_data,
                        x=short_data.index,
                        y='Short Volume',
                        title="Short Selling Volume"
                    )
                    if 'Short Ratio' in short_data.columns:
                        fig.add_trace(
                            go.Scatter(
                                x=short_data.index,
                                y=short_data['Short Ratio'],
                                mode='lines',
                                name='Short Ratio',
                                yaxis='y2'
                            )
                        )
                        fig.update_layout(
                            yaxis2=dict(
                                title='Short Ratio',
                                overlaying='y',
                                side='right'
                            )
                        )
                    st.plotly_chart(fig, use_container_width=True)
                except Exception as e:
                    st.warning(f"Could not generate Short Selling visualization: {str(e)}")
    
    with tabs[2]:  # Export tab
        st.header("Export Data")
        
        # Big prominent download button at the top
        st.markdown("### 📥 Download All Scraped Data")
        
        # Create an Excel file for all scraped data
        excel_manager = ExcelManager(output_dir="data")
        file_name = f"{stock_symbol}_{start_date.strftime('%Y%m%d')}_{end_date.strftime('%Y%m%d')}.xlsx"
        export_path = excel_manager.export_multiple_sheets(st.session_state.scraped_data, file_name)
        
        # Display large central download button
        if export_path and os.path.exists(export_path):
            try:
                with open(export_path, "rb") as f:
                    excel_data = f.read()
                    download_filename = f"{stock_symbol}_complete_data_{start_date.strftime('%Y%m%d')}_{end_date.strftime('%Y%m%d')}.xlsx"
                    
                    # Create a centered column for the main download button
                    col1, col2, col3 = st.columns([1, 2, 1])
                    with col2:
                        st.download_button(
                            label="⬇️ DOWNLOAD COMPLETE DATASET (.xlsx)",
                            data=excel_data,
                            file_name=download_filename,
                            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            key="export_tab_download_button"
                        )
                        st.success(f"Excel file includes {len(st.session_state.scraped_data)} data sheets with all scraped information")
            except Exception as e:
                st.error(f"Error preparing Excel file: {str(e)}")
        else:
            st.warning("Could not create the main Excel file for download. Please use the individual format options below.")
        
        st.markdown("---")
        
        # Additional format options in separate sections
        st.markdown("### Additional Format Options")
        csv_col, excel_col = st.columns(2)
        
        with csv_col:
            st.subheader("CSV Downloads")
            st.write("Download individual data components as CSV files")
            
            # CSV export buttons for each data type
            for data_type, data in st.session_state.scraped_data.items():
                if not data.empty:
                    csv_data = data.to_csv(index=True)
                    safe_name = data_type.replace("/", "_").replace(" ", "_")
                    filename = f"{stock_symbol}_{safe_name}_{start_date.strftime('%Y%m%d')}_{end_date.strftime('%Y%m%d')}.csv"
                    st.download_button(
                        label=f"Download {data_type} as CSV",
                        data=csv_data,
                        file_name=filename,
                        mime="text/csv",
                        key=f"csv_{safe_name}"
                    )
        
        with excel_col:
            st.subheader("Individual Excel Files")
            st.write("Download separate Excel files for each data type")
            
            # Excel export buttons for each data type
            for data_type, data in st.session_state.scraped_data.items():
                if not data.empty:
                    # Create individual Excel file for this data type
                    try:
                        individual_file_name = f"{stock_symbol}_{data_type.replace('/', '_').replace(' ', '_')}_{start_date.strftime('%Y%m%d')}_{end_date.strftime('%Y%m%d')}.xlsx"
                        individual_path = excel_manager.export_to_excel(data, individual_file_name, sheet_name=data_type)
                        
                        if individual_path and os.path.exists(individual_path):
                            with open(individual_path, "rb") as f:
                                excel_data = f.read()
                                st.download_button(
                                    label=f"Download {data_type} as Excel",
                                    data=excel_data,
                                    file_name=individual_file_name,
                                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                    key=f"excel_{data_type.replace('/', '_').replace(' ', '_')}"
                                )
                    except Exception as e:
                        st.warning(f"Could not create Excel file for {data_type}: {str(e)}")
        
        # Add a note about the exports
        st.markdown("---")
        st.info("💡 All downloaded files contain the real scraped data from your selected data source.")
        st.markdown("📊 The complete dataset (.xlsx) contains all data types in separate sheets for easier analysis.")


# Display a note about the app when no data is loaded
if not st.session_state.scraping_complete:
    st.write("""
    ## How to use this app:
    1. Select a data source (NSE, BSE, Google Finance, Yahoo Finance, or Investing.com)
    2. Enter the stock symbol/ticker you're interested in
    3. Choose the types of data you want to retrieve:
       - Price data, technical indicators (SMA, EMA, RSI, MACD, Bollinger Bands)
       - Volume metrics (Volume MA, OBV, VWAP, MFI)
       - Market data (FII/DII activity, block deals, bulk deals, short selling)
    4. Select a time period or set a custom date range
    5. Configure indicator-specific parameters using the sliders
    6. Click "Fetch Data" to retrieve, analyze, and visualize the information
    7. Use the tabs to view data tables, interactive visualizations, or export to CSV/Excel
    """)
    
    # Information about data sources
    st.write("### Data Sources Information")
    with st.expander("About the available data sources"):
        st.markdown("""
        - **NSE (National Stock Exchange)**: India's leading stock exchange (Use symbols like RELIANCE, INFY, TCS)
        - **BSE (Bombay Stock Exchange)**: India's oldest stock exchange (Use symbols like RELIANCE, INFY, TCS)
        - **Google Finance**: Global market data (Use symbols like GOOGL, AAPL, MSFT)
        - **Yahoo Finance**: Comprehensive global data (Use symbols like AAPL, GOOGL, or RELIANCE.NS for Indian stocks)
        - **Investing.com**: Global market data covering stocks, forex, commodities, and crypto
        """)
    
    # Information about the indicators
    st.write("### Technical Indicators")
    with st.expander("Learn about the available technical indicators"):
        st.markdown("""
        - **SMA (Simple Moving Average)**: Average price over specified period, helps identify trends
        - **EMA (Exponential Moving Average)**: Weighted average giving more importance to recent prices
        - **RSI (Relative Strength Index)**: Momentum oscillator measuring speed/change of price movements
        - **MACD (Moving Average Convergence Divergence)**: Trend-following momentum indicator
        - **Bollinger Bands**: Volatility bands placed above/below a moving average
        - **Volume Analysis**: Includes Volume MA, OBV, VWAP and MFI for volume-based market insights
        """)
    
    st.info("Select a data source, stock symbol, and click 'Fetch Data' to see actual data and visualizations.")
